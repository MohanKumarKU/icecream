function handlevisibility(component,status)
{
	var id=component;
	
	if(status=='success')
	{
		component=component+status;
		
		
		var elementToBeRemoved = document.getElementById(id+"filter");
	 
	 if(elementToBeRemoved!=null)
	 {	 
    elementToBeRemoved.parentNode.removeChild(elementToBeRemoved);
	 }
	 
	 var element=document.createElement("img");
	 
	 element.src = 'resources/images/tick_mark.png';
	 
	 element.setAttribute("width", "20px");
	 element.setAttribute("height","20px");
	 element.setAttribute("id",id+"filter");
	 
	 document.getElementById(id+"badge").appendChild(element);
	 
	 
		
	  $("."+id+"failure").hide();
	  $("."+id+"success").show();
	  
	}
	
	else if(status=='failure')
	{
		component=component+status;
		 var elementToBeRemoved = document.getElementById(id+"filter");
    
	 if(elementToBeRemoved!=null)
	 {	 
    elementToBeRemoved.parentNode.removeChild(elementToBeRemoved);
	 }
	 var element=document.createElement("img");
	 
	 element.src = 'resources/images/wrong_image.png';
	 
	 element.setAttribute("width", "20px");
	 element.setAttribute("height","20px");
	 
	 element.setAttribute("id",id+"filter");
	 
	
	 
	 document.getElementById(id+"badge").appendChild(element); 
		 
		 
		 
	  $("."+id+"success").hide();
	  $("."+id+"failure").show();
	  

	}
	
	else 
	{
		
		var elementToBeRemoved = document.getElementById(id+"filter");
    
	 if(elementToBeRemoved!=null)
	 {	 
    elementToBeRemoved.parentNode.removeChild(elementToBeRemoved);
	 } 
		
	  $("."+id+"success").show();
	  $("."+id+"failure").show();
	  
	}

	

	
}


function modifyVisiblity(id)
{
	
	$(".panel-collapse.collapse").hide();
	
	if(id=='tick_testcase')
	{
		
		var elementToBeRemoved = document.getElementById("testcase");
	 
	 if(elementToBeRemoved!=null)
	 {	 
    elementToBeRemoved.parentNode.removeChild(elementToBeRemoved);
	 }
	 
	 var element=document.createElement("img");
	 
	 element.src = '../resources/images/tick_mark.png';
	 
	 element.setAttribute("width", "20px");
	 element.setAttribute("height","20px");
	 element.setAttribute("id",'testcase');
	 
	 document.getElementById("badge").appendChild(element);
	 
	 
		
	  $(".panel-heading.failurecase").hide();
	  $(".panel-heading.successcase").show();
	  
	}
	
	else if(id=='wrong_testcase')
	{
		 
		 var elementToBeRemoved = document.getElementById("testcase");
    
	 if(elementToBeRemoved!=null)
	 {	 
    elementToBeRemoved.parentNode.removeChild(elementToBeRemoved);
	 }
	 var element=document.createElement("img");
	 
	 element.src = '../resources/images/wrong_image.png';
	 
	 element.setAttribute("width", "20px");
	 element.setAttribute("height","20px");
	 
	 element.setAttribute("id",'testcase');
	 
	 document.getElementById("badge").appendChild(element); 
		 
		 
		 
	  $(".panel-heading.successcase").hide();
	  $(".panel-heading.failurecase").show();
	  

	}
	
	else if(id=='all_testcase')
	{
		
		var elementToBeRemoved = document.getElementById("testcase");
    
	 if(elementToBeRemoved!=null)
	 {	 
    elementToBeRemoved.parentNode.removeChild(elementToBeRemoved);
	 } 
		
	  $(".panel-heading.successcase").show();
	  $(".panel-heading.failurecase").show();
	  
	}


	
}


function changevisibility(id)
{
	
if(id=='success')
{
	$(".successrow").show();
	$(".failurerow").hide();
	}
else if(id=='failure')
	{
	$(".failurerow").show();
	$(".successrow").hide();
	
	}
else
	{
	
	$(".successrow").show();
	$(".failurerow").show();
	
	}
}



















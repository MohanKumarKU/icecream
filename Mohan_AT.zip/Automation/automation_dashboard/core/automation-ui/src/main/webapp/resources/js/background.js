function changeBackground(id)

	{

	
	document.getElementById(id).style.backgroundColor = "#9ACD32";

		
	}
	


function getBackground(id)
	{

	
	document.getElementById(id).style.backgroundColor = "#2A3F54";
		
	}
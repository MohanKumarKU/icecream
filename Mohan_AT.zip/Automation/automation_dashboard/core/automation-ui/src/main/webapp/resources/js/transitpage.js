function doPagination(data) {
	
	var i=0;
	
        var obj = $('#pagination').twbsPagination({
            
        	totalPages: data.length,
        	
            visiblePages: 6,
            
            
            onPageClick: function (event, page) {
                alert(page);
            }
        	
        
        
        });
        console.info(obj.data());
    }
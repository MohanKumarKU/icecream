function plotpiegraph(success,failure,id)
	{
		
	
	
	Highcharts.setOptions({
		 colors: ['#00CA00', '#FD0000']
		});
	
	
		var chart_data=[["Success",(success*100)/(parseFloat(success)+parseFloat(failure))],["Failure",(failure*100)/(parseFloat(success)+parseFloat(failure))]];	
				
	    // Build the chart
	    $("#"+id).highcharts({
	        chart: {
	            plotBackgroundColor: '#FFFFFF',
	            plotBorderWidth: null,
	            plotShadow: false,
	            type: 'pie',
	            width:220,
	            height:180
	        },
	        title:{
			text:''
			
			},
			credits:{
				enabled:false
			},
			
			 exporting: {
		            
		            buttons: {
		            	
		            	contextButton:{enabled:false},
		            	
		                exportButton: {
		                	
		                	text: 'Menu',
		                	
		                    menuItems: [{
		                        text: 'Bar Chart',
		                        onclick:function(){
		                        	plotbargraph(success,failure,id);
		                        	
		                        }
		                        
		                    }, {
		                        text: 'Column Chart',
		                        onclick: function () {
		                        	plotcolumngraph(success,failure,id);

		                        }
		                    },
		                    null,
		                    null]
		                }
		            }
		        },

			 
	        tooltip: {
	        	 pointFormat: '<b>{point.percentage:.1f}%</b>'
	        },
	        plotOptions: {
	        	pie: {
	                allowPointSelect: true,
	                cursor: 'pointer',
	                showInLegend: false,
	                dataLabels: {
	                    enabled: true,
	                    formatter: function() {
	                        return Math.round(this.y*100)/100 + ' %';
	                    },
	                    distance: -30,
	                    color:'white'
	                    
	                },
	                
	            }
	        },
	        
	        series: [{
	            name:'Success',
	            colorByPoint: true,
	            data: [{
	                name: chart_data[0][0],
	                y: chart_data[0][1]
	            }, {
	                name: chart_data[1][0],
	                y: chart_data[1][1],
	                sliced: false,
	                selected: true
	            }]
	        }]
	    });		
	}



	function plotbargraph(success,failure,id)
	{
		
		
		
		var chart_data=[["Success",(success*100)/(parseFloat(success)+parseFloat(failure))],["Failure",(failure*100)/(parseFloat(success)+parseFloat(failure))]];	

		
		
	    // Build the chart
	    $("#"+id).highcharts({
	        chart: {
	            plotBackgroundColor: '#FFFFFF',
	            plotBorderWidth: null,
	            plotShadow: false,
	            type: 'bar',
	            width:220,
	            height:180
	        },
	        title:{
			text:''
			
			},
			credits:{
				enabled:false
			},
			
			 exporting: {
		            
		            buttons: {
		            	
		            	contextButton:{enabled:false},
		            	
		                exportButton: {
		                	
		                	text: 'Menu',
		                	
		                    menuItems: [{
		                        text: 'Pie Chart',
		                        onclick:function(){
		                        	plotpiegraph(success,failure,id);
		                        	
		                        }
		                        
		                    }, {
		                        text: 'Column Chart',
		                        onclick: function () {
		                        	plotcolumngraph(success,failure,id);

		                        }
		                    },
		                    null,
		                    null]
		                }
		            }
		        },

			 
	        tooltip: {
	        	pointFormat: '<b>{point.percentage:.1f}%</b>'
	        },
	        plotOptions: {
	        	bar: {
	                allowPointSelect: true,
	                cursor: 'pointer',
	                showInLegend: false,
	                dataLabels: {
	                    enabled: true,
	                    formatter: function() {
	                        return Math.round(this.y*100)/100 + ' %';
	                    },
	                    distance: -30,
	                    color:'white'
	                    
	                },
	                
	            }
	        },
	        
	        series: [{
	            name:'Success',
	            colorByPoint: true,
	            data: [{
	                name: chart_data[0][0],
	                y: chart_data[0][1]
	            }, {
	                name: chart_data[1][0],
	                y: chart_data[1][1],
	                sliced: true,
	                selected: true
	            }]
	        }]
	    });		
	}


	function plotcolumngraph(success,failure,id)
	{
		
		var chart_data=[["Success",(success*100)/(parseFloat(success)+parseFloat(failure))],["Failure",(failure*100)/(parseFloat(success)+parseFloat(failure))]];	
		
		
		
	    // Build the chart
	    $("#"+id).highcharts({
	        chart: {
	            plotBackgroundColor: '#FFFFFF',
	            plotBorderWidth: null,
	            plotShadow: false,
	            type: 'column',
	            width:220,
	            height:180
	        },
	        title:{
			text:''
			
			},
			credits:{
				enabled:false
			},
			
			 exporting: {
		            
		            buttons: {
		            	
		            	contextButton:{enabled:false},
		            	
		                exportButton: {
		                	
		                	text: 'Menu',
		                	
		                    menuItems: [{
		                        text: 'Pie Chart',
		                        onclick:function(){
		                        	plotpiegraph(success,failure,id);
		                        	
		                        }
		                        
		                    }, {
		                        text: 'Bar Chart',
		                        onclick: function () {
		                        	plotbargraph(success,failure,id);

		                        }
		                    },
		                    null,
		                    null]
		                }
		            }
		        },

			 
	        tooltip: {
	        	pointFormat: '<b>{point.percentage:.1f}%</b>'
	        },
	        plotOptions: {
	        	column: {
	                allowPointSelect: true,
	                cursor: 'pointer',
	                showInLegend: false,
	                dataLabels: {
	                    enabled: true,
	                    formatter: function() {
	                        return Math.round(this.y*100)/100 + ' %';
	                    },
	                    distance: -30,
	                    color:'white'
	                    
	                },
	                
	            }
	        },
	        
	        series: [{
	            name:'Success',
	            colorByPoint: true,
	            data: [{
	                name: chart_data[0][0],
	                y: chart_data[0][1]
	            }, {
	                name: chart_data[1][0],
	                y: chart_data[1][1],
	                sliced: true,
	                selected: true
	            }]
	        }]
	    });				
		
		
	}
	
	
	
	
	function drawpiechart(id,automatedinbvt,automatednotinbvt,tobeautomated,automatedcasesinbvt,automatedcasesnotinbvt,tobeautomatedcases,word)
	{
	
	
	Highcharts.setOptions({
 colors: ['#00AA00', '#5DA5DA','#F00C00', '#B2912F','#B8860B','#C0C0C0','#00ACEF']
});
	
	  // Build the chart
    $("#"+id).highcharts({
        chart: {
            plotBackgroundColor: '#FFFFFF',
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie',
            width:280,
            height:300
        },
        title:{
		text:''
		
		},
		credits:{
			enabled:false
		},
		
		exporting: {
            
            buttons: {
            	
            	contextButton:{enabled:false},
            	
                exportButton: {
                	
                	text: 'Options',
                	
                    menuItems: [{
                        text: 'By Test Cases',
                        onclick:function(){
                        	drawpiechart_testcases(id,automatedinbvt,automatednotinbvt,tobeautomated,automatedcasesinbvt,automatedcasesnotinbvt,tobeautomatedcases," Test cases");
                        }
                        
                    }, {
                        text: 'By Test Steps',
                        onclick: function () {
                        	
                        }
                    },
                    null,
                    null]
                }
            }
        },

		 
        tooltip: {
            pointFormat: '<b>{point.y}</b> '+word
        },
        plotOptions: {
        	pie: {
                
                showInLegend: true,
                dataLabels: {
                    enabled: true,
                    formatter: function() {
                        return Math.round(this.percentage*100)/100 + ' %';
                    },
                    distance: -30,
                    color:'white'
                    
                },
                
            }
        },
        
        legend:{
        
            verticalAlign: 'bottom',
        },
        
        series: [{
            name:'Automation',
            colorByPoint: true,
            data: [{
                name: "Automated and in BVT",
                y: automatedinbvt
            },
            {
                name: "Automated and Not in BVT",
                y: automatednotinbvt
            },
            {
                name: "Yet to be Automated",
                y: tobeautomated,
                sliced: false,
                selected: true
            }]
        }]
    });
	

	
	}
	
	
	
	function drawpiechart_testcases(id,automatedinbvt,automatednotinbvt,tobeautomated,automatedcasesinbvt,automatedcasesnotinbvt,tobeautomatedcases,word)
	{
	
	
	
	  // Build the chart
    $("#"+id).highcharts({
        chart: {
            plotBackgroundColor: '#FFFFFF',
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie',
            width:280,
            height:300
        },
        title:{
		text:''
		
		},
		credits:{
			enabled:false
		},
		
		exporting: {
            
            buttons: {
            	
            	contextButton:{enabled:false},
            	
                exportButton: {
                	
                	text: 'Options',
                	
                    menuItems: [{
                        text: 'By Test Cases',
                        onclick:function(){
                        	
                        }
                        
                    }, {
                        text: 'By Test Steps',
                        onclick: function () {
                        	drawpiechart(id,automatedinbvt,automatednotinbvt,tobeautomated,automatedcasesinbvt,automatedcasesnotinbvt,tobeautomatedcases," Test steps");
                        }
                    },
                    null,
                    null]
                }
            }
        },

		 
        tooltip: {
            pointFormat: '<b>{point.y}</b> '+word
        },
        plotOptions: {
        	pie: {
                
                showInLegend: true,
                dataLabels: {
                    enabled: true,
                    formatter: function() {
                        return Math.round(this.percentage*100)/100 + ' %';
                    },
                    distance: -30,
                    color:'white'
                    
                },
                
            }
        },
        
        legend:{
        
            verticalAlign: 'bottom',
        },
        
        series: [{
            name:'Automation',
            colorByPoint: true,
            data: [{
                name: "Automated and in BVT",
                y: automatedcasesinbvt
            },
            {
                name: "Automated and Not in BVT",
                y: automatedcasesnotinbvt
            },
            {
                name: "Yet to be Automated",
                y: tobeautomatedcases,
                sliced: false,
                selected: true
            }]
        }]
    });
	

	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

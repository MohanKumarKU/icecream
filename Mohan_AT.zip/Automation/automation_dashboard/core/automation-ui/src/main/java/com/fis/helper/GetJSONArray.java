package com.fis.helper;

import java.sql.SQLException;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.fis.automation.bean.BUILD_COVERAGE_BEAN;
import com.fis.automation.bean.BUILD_HIST_LATEST_RES;

public class GetJSONArray {

	
	
	 public static JSONArray convert( List<BUILD_COVERAGE_BEAN> rs )
			    throws SQLException, JSONException
			  {
			    JSONArray json = new JSONArray();
			    
			    for(BUILD_COVERAGE_BEAN b:rs) {
			      
			      JSONObject obj = new JSONObject();
			         
			      
			         obj.put("SRVC_OPRTN_NAME", b.getSRVC_OPRTN_NAME());
			        obj.put("TEST_CASE_CNT",Integer.parseInt(b.getTEST_CASE_CNT()));
			        obj.put("TEST_STEP_CNT",Integer.parseInt(b.getTEST_STEP_CNT()));
			      
			        json.put(obj);
			      }


			    return json;
			  }
	
	
	
}

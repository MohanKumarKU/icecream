package com.fis.helper;

import java.util.List;
import java.util.Map;

import com.fis.automation.bean.BUILD_COVERAGE_BEAN;
import com.fis.automation.bean.BUILD_HIST;
import com.fis.automation.bean.BUILD_HIST_AVG_TIME;
import com.fis.automation.bean.BUILD_HIST_DTL;
import com.fis.automation.bean.BUILD_HIST_LATEST_RES;
import com.fis.automation.bean.CMPNT_RELEASE_DTL;
import com.fis.automation.bean.CMPNT_RELEASE_DTL_ID;
import com.fis.automation.bean.MAX_TIME_SRVCNAME;
import com.fis.automation.contract.GetCmpRelDbServerDetailsByIdContract;
import com.fis.automation.contract.GetCoverageDetailsContract;
import com.fis.automation.contract.GetDashboardDataContract;
import com.fis.automation.contract.GetRequiredBuildContract;
import com.fis.automation.contract.GetTestCaseListContract;
import com.fis.automation.facade.GetCmpRelDbServerDetailsByIdFacade;
import com.fis.automation.facade.GetCoverageDetailsFacade;
import com.fis.automation.facade.GetDashboardDataFacade;
import com.fis.automation.facade.GetRequiredBuildFacade;
import com.fis.automation.facade.GetTestCaseListFacade;

public class DashboardHelper
{

	static GetCmpRelDbServerDetailsByIdContract contract =new 	GetCmpRelDbServerDetailsByIdFacade();	
	static GetDashboardDataContract componentContract=new GetDashboardDataFacade();
	static GetTestCaseListContract testcaseContract=new GetTestCaseListFacade();
	static  GetRequiredBuildContract buildContract=new GetRequiredBuildFacade();
	static GetCoverageDetailsContract coverageContract=new GetCoverageDetailsFacade();
	
	static List<String> componentList=null;

	
	public static List<String> getAllComponents()
	{
		if(componentList==null)
		return componentContract.getAllComponents();
		
		return componentList;
		
	}
	
	
	public static List<CMPNT_RELEASE_DTL> getComponentReleaseDtlById(String cmpreldtl_id) 
	{
		return contract.getCmpRelDbServerDetails(cmpreldtl_id);
	}
	
	public static List<CMPNT_RELEASE_DTL_ID> getComponentReleaseDtl(String component, String release) 
	{
		return contract.getCmpntReleaseIDDtl(component,release);
	}
	
	public static List<BUILD_HIST_LATEST_RES> getRequiredBuildInfoDetails(String cmpreldtl_id) 
	{
		return buildContract.getRequiredBuildInfoDetails(cmpreldtl_id);
	}
	
	
	public static List<String> getAllowedServerDatabaseCombinations(String component,String release)
	{
		return contract.getAllowedServerDatabaseCombinations(component, release);
	}
	
	
	public static Map<String,String> getLatestReleaseForComponents()
	{
	 	return componentContract.getLatestReleaseForComponents();
	}
	
	public static String getPreviousReleaseForComponents(String cmpnt_name, String release_no)
	{
	 	return componentContract.getPreviousReleaseForComponents(cmpnt_name, release_no);
	}
	
	public static List<BUILD_HIST> getAllBuildsByComponentReleaseDtlId(String cmpreldtl_id)
	{
		return contract.getAllBuildsByComponentReleaseDtlId(cmpreldtl_id);
	}
	
	
	public static List<BUILD_HIST> getLatestBuildHistDetails(String cmpreldtl_id)
	{
		return contract.getLatestBuildHistDetails(cmpreldtl_id);
	}
	
	
	
	public static Map<String,String> getAllTestcasesList(String build_no,String cmpreldtl_id)
	{
		return testcaseContract.getTestCaseList(build_no, cmpreldtl_id);
	}
	
	
	public static Map<String,String> getTestCaseStepCounts(String build_no,String cmpreldtl_id)
	{
		return testcaseContract.getTestCaseStepCounts(build_no, cmpreldtl_id);
	}
	
	
	public static List<BUILD_HIST> getRequiredBuildHistDetails(String build_no,String cmpntreldtl_id)
	{
			return buildContract.getRequiredBuildInformation(build_no, cmpntreldtl_id);
	}
	
	
	public static List<BUILD_HIST_DTL> getAccordionContent(String build_no,String testcasename,String cmpntreldtl_id,String component)
	{
		return buildContract.getAccordionContent(build_no, testcasename, cmpntreldtl_id,component);
		
	}
	
	
	public static List<String> getAllNonAutomatedServices(String build_no,String cmpreldtl_id)
	{
		return coverageContract.getAllNonAutomatedServices(build_no, cmpreldtl_id);
	}
	
	
	public static int [] getAutomatedPercentage(String build_no,String cmpreldtl_id)
	{
		return coverageContract.getAutomatedPercentage(build_no, cmpreldtl_id);
	}
	
	
	public static List<BUILD_COVERAGE_BEAN> getAutomatedTestcaseInfo(String build_no,String cmpreldtl_id)
	{
		return coverageContract.getAutomatedTestcaseInfo(build_no, cmpreldtl_id);
	}
	
	public static List<BUILD_HIST_AVG_TIME> getAvgBVTTime(String component) 
	{
		return buildContract.getAvgBVTTime(component);
	}
	
	public static List<MAX_TIME_SRVCNAME> getMaxTimeScrvName(String cmpreldtl_id) 
	{
		return buildContract.getMaxTimeScrvName(cmpreldtl_id);
	}
	
}

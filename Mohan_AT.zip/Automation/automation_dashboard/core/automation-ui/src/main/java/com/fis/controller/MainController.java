package com.fis.controller;

import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fis.automation.bean.BUILD_COVERAGE_BEAN;
import com.fis.automation.bean.BUILD_HIST;
import com.fis.automation.bean.BUILD_HIST_AVG_TIME;
import com.fis.automation.bean.BUILD_HIST_DTL;
import com.fis.automation.bean.BUILD_HIST_LATEST_RES;
//import com.fis.automation.bean.BUILD_HIST_LATEST_RES;
import com.fis.automation.bean.CMPNT_RELEASE_DTL;
import com.fis.automation.bean.CMPNT_RELEASE_DTL_ID;
import com.fis.automation.bean.MAX_TIME_SRVCNAME;
import com.fis.automation.contract.GetCmpRelDbServerDetailsByIdContract;
import com.fis.automation.durationhandler.DefaultServerDatabase;
import com.fis.automation.durationhandler.DurationStorer;
import com.fis.automation.facade.GetCmpRelDbServerDetailsByIdFacade;
import com.fis.helper.DashboardHelper;
import com.fis.helper.ExcelReader;
import com.fis.helper.GetJSONArray;

@Controller
public class MainController {

	GetCmpRelDbServerDetailsByIdContract contract = new GetCmpRelDbServerDetailsByIdFacade();

	@RequestMapping("/")
	public ModelAndView showMainPage() {
		ModelAndView model = new ModelAndView("dashboard");

		// fetch component list
		List<String> componentList = DashboardHelper.getAllComponents();

		Map<String, List<BUILD_HIST>> componentBuilds = new LinkedHashMap<String, List<BUILD_HIST>>();

		List<BUILD_HIST> build_data = null;
		Map<String, BUILD_HIST> dashboardDetails = new HashMap<String, BUILD_HIST>();

		Map<String, List<String>> allowedDbServerCombinations = new HashMap<String, List<String>>();

		Map<String, String> releaseMap = DashboardHelper
				.getLatestReleaseForComponents();

		Map<String, String> idStorer = new HashMap<String, String>();

		String generated_id = "";
		String release_no = null;
		// for each component get All the Builds

		if (componentList != null) {

			for (String s : componentList) {
				release_no = null;
				// build_data=contract.getAllBuildsForComponent(s);
				generated_id = contract.getCmpntReleaseDtlId(s,
						releaseMap.get(s), DefaultServerDatabase.getDATABASE(),
						DefaultServerDatabase.getSERVER());

				idStorer.put(s, generated_id);

				allowedDbServerCombinations.put(s, DashboardHelper
						.getAllowedServerDatabaseCombinations(s,
								releaseMap.get(s)));

				build_data = DashboardHelper
						.getAllBuildsByComponentReleaseDtlId(generated_id);

				List<BUILD_HIST> latestBuildHistDetails = DashboardHelper
						.getLatestBuildHistDetails(generated_id);

				while (latestBuildHistDetails == null) {
					if (release_no == null)
						release_no = DashboardHelper
								.getPreviousReleaseForComponents(s,
										releaseMap.get(s));
					else
						release_no = DashboardHelper
								.getPreviousReleaseForComponents(s, release_no);

					generated_id = contract.getCmpntReleaseDtlId(s, release_no,
							DefaultServerDatabase.getDATABASE(),
							DefaultServerDatabase.getSERVER());

					idStorer.put(s, generated_id);

					allowedDbServerCombinations.put(s,
							DashboardHelper
									.getAllowedServerDatabaseCombinations(s,
											release_no));

					build_data = DashboardHelper
							.getAllBuildsByComponentReleaseDtlId(generated_id);

					latestBuildHistDetails = DashboardHelper
							.getLatestBuildHistDetails(generated_id);

				}

				if (!latestBuildHistDetails.isEmpty()) {
					dashboardDetails.put(s, latestBuildHistDetails.get(0));
				} else
					dashboardDetails.put(s, null);

				componentBuilds.put(s, build_data);
			}

		}

		model.addObject("componentlist", componentList);
		model.addObject("componentBuilds", componentBuilds);
		model.addObject("dashboardDetails", dashboardDetails);
		model.addObject("releaseMap", releaseMap);
		model.addObject("idStorer", idStorer);
		model.addObject("defaultdb", DefaultServerDatabase.getDATABASE());
		model.addObject("defaultserver", DefaultServerDatabase.getSERVER());
		model.addObject("allowedDbServerCombinations",
				allowedDbServerCombinations);
		return model;
	}

	@RequestMapping("/showcomponent/{id}")
	public ModelAndView showComponentPage(
			@PathVariable(value = "id") String cmpreldtl_id) {

		ModelAndView model = new ModelAndView("component");

		List<String> componentList = DashboardHelper.getAllComponents();

		List<BUILD_HIST> build = DashboardHelper
				.getLatestBuildHistDetails(cmpreldtl_id);

		Map<String, String> testcasesList = null;

		Map<String, String> mainList = null;

		Map<String, String> idStorer = new HashMap<String, String>();

		Map<String, String> releaseMap = new HashMap<String, String>();

		releaseMap = DashboardHelper.getLatestReleaseForComponents();

		String generated_id = "";

		if (build != null && !build.isEmpty()) {

			testcasesList = DashboardHelper.getAllTestcasesList(build.get(0)
					.getBUILD_NMBR(), cmpreldtl_id);

			mainList = DashboardHelper.getTestCaseStepCounts(build.get(0)
					.getBUILD_NMBR(), cmpreldtl_id);

			for (String s : componentList) {
				generated_id = contract.getCmpntReleaseDtlId(s,
						releaseMap.get(s), DefaultServerDatabase.getDATABASE(),
						DefaultServerDatabase.getSERVER());

				idStorer.put(s, generated_id);
			}

			model.addObject("secret_id", cmpreldtl_id);
			model.addObject("component", build.get(0).getCMPNT_NAME());
			model.addObject("componentList", componentList);

			model.addObject("idStorer", idStorer);

			model.addObject("executionDetails", build.get(0));
			model.addObject("dashboardData", build.get(0));
			model.addObject("testcases", testcasesList);
			model.addObject("mainresult", mainList);
			model.addObject("releaseMap", releaseMap);
			model.addObject("allComponentBuilds", DashboardHelper
					.getAllBuildsByComponentReleaseDtlId(cmpreldtl_id));

		}

		return model;

	}

	@RequestMapping("/showcomponentparticular{id}/{id1}")
	public ModelAndView showcomponentparticularpage(
			@PathVariable(value = "id") String cmpntreldtl_id,
			@PathVariable(value = "id1") String build_no) {
		ModelAndView model = new ModelAndView("component");

		List<String> componentList = DashboardHelper.getAllComponents();

		List<BUILD_HIST> build = DashboardHelper.getRequiredBuildHistDetails(
				build_no, cmpntreldtl_id);

		Map<String, String> testcasesList = null;

		Map<String, String> mainList = null;

		Map<String, String> idStorer = new HashMap<String, String>();

		Map<String, String> releaseMap = new HashMap<String, String>();

		releaseMap = DashboardHelper.getLatestReleaseForComponents();

		String generated_id = "";

		if (build != null && !build.isEmpty()) {

			testcasesList = DashboardHelper.getAllTestcasesList(build.get(0)
					.getBUILD_NMBR(), cmpntreldtl_id);

			mainList = DashboardHelper.getTestCaseStepCounts(build.get(0)
					.getBUILD_NMBR(), cmpntreldtl_id);

			for (String s : componentList) {
				generated_id = contract.getCmpntReleaseDtlId(s,
						releaseMap.get(s), DefaultServerDatabase.getDATABASE(),
						DefaultServerDatabase.getSERVER());

				idStorer.put(s, generated_id);
			}

			model.addObject("secret_id", cmpntreldtl_id);
			model.addObject("component", build.get(0).getCMPNT_NAME());
			model.addObject("componentList", componentList);

			model.addObject("idStorer", idStorer);

			model.addObject("executionDetails", build.get(0));
			model.addObject("dashboardData", build.get(0));
			model.addObject("testcases", testcasesList);
			model.addObject("mainresult", mainList);
			model.addObject("releaseMap", releaseMap);
			model.addObject("allComponentBuilds", DashboardHelper
					.getAllBuildsByComponentReleaseDtlId(cmpntreldtl_id));

		}

		return model;
	}

	@RequestMapping(value = "/getAccordionContent", produces = "application/json")
	public @ResponseBody
	List<BUILD_HIST_DTL> getAccordionContent(
			@RequestParam(value = "testcasename") String testcasename,
			@RequestParam(value = "build_no") String build_no,
			@RequestParam(value = "component_release_id") String cmpntreldtl_id,
			@RequestParam(value = "component") String component) {

		List<BUILD_HIST_DTL> build_bean = DashboardHelper.getAccordionContent(
				build_no, testcasename, cmpntreldtl_id, component);

		return build_bean;

	}

	@RequestMapping(value = "/showsettings")
	public ModelAndView showSettings() {
		ModelAndView model = new ModelAndView("settings");

		Map<String, String> idStorer = new HashMap<String, String>();

		Map<String, String> releaseMap = new HashMap<String, String>();

		releaseMap = DashboardHelper.getLatestReleaseForComponents();

		String generated_id = "";

		List<String> componentList = new ArrayList<String>();

		componentList = DashboardHelper.getAllComponents();

		for (String s : componentList) {
			generated_id = contract.getCmpntReleaseDtlId(s, releaseMap.get(s),
					DefaultServerDatabase.getDATABASE(),
					DefaultServerDatabase.getSERVER());

			idStorer.put(s, generated_id);
		}

		model.addObject("idStorer", idStorer);
		model.addObject("componentList", componentList);
		model.addObject("releaseMap", releaseMap);

		return model;

	}

	@RequestMapping(value = "/showcoverage/{id}")
	public ModelAndView showcoveragePage(
			@PathVariable(value = "id") String cmpreldtl_id) {
		ModelAndView model = new ModelAndView("coverage");

		List<BUILD_HIST> build = DashboardHelper
				.getLatestBuildHistDetails(cmpreldtl_id);

		Map<String, String> idStorer = new HashMap<String, String>();

		Map<String, String> releaseMap = new HashMap<String, String>();

		releaseMap = DashboardHelper.getLatestReleaseForComponents();

		String generated_id = "";

		List<String> componentList = new ArrayList<String>();

		componentList = DashboardHelper.getAllComponents();

		String build_no = "";

		if (build != null && !build.isEmpty()) {
			build_no = build.get(0).getBUILD_NMBR();
		}

		for (String s : componentList) {
			generated_id = contract.getCmpntReleaseDtlId(s, releaseMap.get(s),
					DefaultServerDatabase.getDATABASE(),
					DefaultServerDatabase.getSERVER());

			idStorer.put(s, generated_id);
		}

		List<String> nonAutomatedServices = DashboardHelper
				.getAllNonAutomatedServices(build_no, cmpreldtl_id);

		int percentage[] = DashboardHelper.getAutomatedPercentage(build_no,
				cmpreldtl_id);

		List<BUILD_COVERAGE_BEAN> beanList = DashboardHelper
				.getAutomatedTestcaseInfo(build_no, cmpreldtl_id);

		model.addObject("nonAutomated", nonAutomatedServices);
		model.addObject("componentList", componentList);
		try {
			model.addObject("coverage", GetJSONArray.convert(beanList));
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (percentage != null) {
			model.addObject("notAutomated", percentage[0]);
			model.addObject("Automated", percentage[1]);
		} else {
			model.addObject("notAutomated", 0);
			model.addObject("Automated", 100);

		}
		model.addObject("component", build.get(0).getCMPNT_NAME());
		model.addObject("idStorer", idStorer);
		model.addObject("build", build_no);
		model.addObject("releaseMap", releaseMap);

		return model;

	}

	@RequestMapping(value = "/{build}showcoverage/{id}")
	@ResponseBody
	public ModelAndView showcoverageParticularPage(
			@PathVariable(value = "build") String build_no,
			@PathVariable(value = "id") String cmpreldtl_id) {
		ModelAndView model = new ModelAndView("coverage");

		Map<String, String> idStorer = new HashMap<String, String>();

		Map<String, String> releaseMap = new HashMap<String, String>();

		releaseMap = DashboardHelper.getLatestReleaseForComponents();

		String generated_id = "";

		List<String> componentList = new ArrayList<String>();

		componentList = DashboardHelper.getAllComponents();

		for (String s : componentList) {
			generated_id = contract.getCmpntReleaseDtlId(s, releaseMap.get(s),
					DefaultServerDatabase.getDATABASE(),
					DefaultServerDatabase.getSERVER());

			idStorer.put(s, generated_id);
		}

		List<String> nonAutomatedServices = DashboardHelper
				.getAllNonAutomatedServices(build_no, cmpreldtl_id);

		int percentage[] = DashboardHelper.getAutomatedPercentage(build_no,
				cmpreldtl_id);

		List<BUILD_COVERAGE_BEAN> beanList = DashboardHelper
				.getAutomatedTestcaseInfo(build_no, cmpreldtl_id);

		List<CMPNT_RELEASE_DTL> cmpDetail = DashboardHelper
				.getComponentReleaseDtlById(cmpreldtl_id);

		model.addObject("nonAutomated", nonAutomatedServices);
		model.addObject("componentList", componentList);
		try {
			model.addObject("coverage", GetJSONArray.convert(beanList));
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (percentage != null) {
			model.addObject("notAutomated", percentage[0]);
			model.addObject("Automated", percentage[1]);
		} else {
			model.addObject("notAutomated", 0);
			model.addObject("Automated", 100);

		}
		model.addObject("component", cmpDetail.get(0).getCMPNT_NAME());
		model.addObject("build", build_no);
		model.addObject("idStorer", idStorer);
		model.addObject("releaseMap", releaseMap);

		return model;

	}

	@RequestMapping(value = "/showweeklyprogress{id}")
	public ModelAndView showWeeklyAutomationProgress(
			@PathVariable(value = "id") String component) {

		ModelAndView model = new ModelAndView("weekly_analysis");

		// List<List<String>> twodList=ExcelReader.readExcelData();

		Map<String, String> idStorer = new HashMap<String, String>();

		Map<String, String> releaseMap = new HashMap<String, String>();

		releaseMap = DashboardHelper.getLatestReleaseForComponents();

		String generated_id = "";

		List<String> componentList = new ArrayList<String>();

		componentList = DashboardHelper.getAllComponents();

		for (String s : componentList) {
			generated_id = contract.getCmpntReleaseDtlId(s, releaseMap.get(s),
					DefaultServerDatabase.getDATABASE(),
					DefaultServerDatabase.getSERVER());

			idStorer.put(s, generated_id);
		}

		model.addObject("idStorer", idStorer);
		model.addObject("component", component);
		model.addObject("componentlist", componentList);
		model.addObject("excelData", ExcelReader.readExcelData(component));
		model.addObject("releaseMap", releaseMap);

		return model;

	}

	@RequestMapping(value = "/setDurationContent")
	public @ResponseBody
	String setDurationContent(
			@RequestParam(value = "startDate") String startDate,
			@RequestParam(value = "endDate") String endDate) {
		Date date1 = null;
		Date date2 = null;
		try {
			date1 = new java.sql.Date(new SimpleDateFormat("dd-MMM-yyyy")
					.parse(startDate).getTime());

			date2 = new java.sql.Date(new SimpleDateFormat("dd-MMM-yyyy")
					.parse(endDate).getTime());

		} catch (ParseException e) {

			return "failed";
		}

		DurationStorer.setStartDate(date1);
		DurationStorer.setEndDate(date2);

		return "Success";

	}

	@RequestMapping(value = "/setDb")
	public @ResponseBody
	String setDb(@RequestParam(value = "database") String database) {

		DefaultServerDatabase.setDATABASE(database.toUpperCase());

		System.out.println(DefaultServerDatabase.getDATABASE());
		return "Success";

	}

	@RequestMapping(value = "/setServer")
	public @ResponseBody
	String setServer(@RequestParam(value = "server") String server) {

		DefaultServerDatabase.setSERVER(server.toUpperCase());

		System.out.println(DefaultServerDatabase.getSERVER());

		return "Success";

	}

	@RequestMapping(value = "/getPerformanceResults", produces = "application/json")
	public @ResponseBody
	
	Map<String, List<BUILD_HIST_LATEST_RES>> getPerformanceResults(
			@RequestParam(value = "component") String component) {
		System.out.println(component);
		
		Map<String, String> releaseMap = new LinkedHashMap<String, String>();
		releaseMap = DashboardHelper.getLatestReleaseForComponents();
		List<CMPNT_RELEASE_DTL_ID> componentRelIDList = null;
		List<BUILD_HIST_LATEST_RES> build_hist_latest_res = null;
		componentRelIDList = DashboardHelper.getComponentReleaseDtl(component,
				releaseMap.get(component));
		Map<String, List<BUILD_HIST_LATEST_RES>> updatedBuildDetails = new LinkedHashMap<String, List<BUILD_HIST_LATEST_RES>>();


		if (componentRelIDList != null) {
			for (CMPNT_RELEASE_DTL_ID sComponentRelID : componentRelIDList) {
				build_hist_latest_res = DashboardHelper
						.getRequiredBuildInfoDetails(sComponentRelID
								.getCMPNT_RELEASE_DTL_ID());
				updatedBuildDetails.put(
						sComponentRelID.getCMPNT_RELEASE_DTL_ID(),
						build_hist_latest_res);
			}
		}
		
		return updatedBuildDetails;
	}

	@RequestMapping(value = "/performancemetrics/{component}")
	public ModelAndView showDemoPage(
			@PathVariable(value = "component") String componentName) {

		ModelAndView model = new ModelAndView("performancemetrics");
		List<String> componentList = DashboardHelper.getAllComponents();
		List<CMPNT_RELEASE_DTL_ID> componentRelIDList = null;
		

		List<BUILD_HIST_AVG_TIME> avgBVTTimeDetails = null;
		Map<String, String> idStorer = new LinkedHashMap<String, String>();
		Map<String, String> releaseMap = new LinkedHashMap<String, String>();
	
		releaseMap = DashboardHelper.getLatestReleaseForComponents();
		String generated_id = "";
		List<BUILD_HIST_LATEST_RES> build_hist_latest_res = null;
		List<MAX_TIME_SRVCNAME> max_time_srvcname = null;
		
		Map<String, List<BUILD_HIST_LATEST_RES>> requiredBuildDetails = new LinkedHashMap<String, List<BUILD_HIST_LATEST_RES>>();
		Map<String, List<MAX_TIME_SRVCNAME>> maxSrvcNameDetails = new LinkedHashMap<String, List<MAX_TIME_SRVCNAME>>();

		
		if (componentList != null && !componentList.isEmpty()) {
			
			model.addObject("component", componentName);
			
			avgBVTTimeDetails = DashboardHelper.getAvgBVTTime(componentName);
			
			componentRelIDList = DashboardHelper.getComponentReleaseDtl(
					componentName, releaseMap.get(componentName));

			if (componentRelIDList != null) {
				for (CMPNT_RELEASE_DTL_ID sComponentRelID : componentRelIDList) {
					
					String sCmpntID = sComponentRelID.getCMPNT_RELEASE_DTL_ID();					
					build_hist_latest_res = DashboardHelper
							.getRequiredBuildInfoDetails(sCmpntID);
					requiredBuildDetails.put(
							sCmpntID,
							build_hist_latest_res);	
				}
			}	
			
			if (componentRelIDList != null) {
				for (CMPNT_RELEASE_DTL_ID sComponentRelID : componentRelIDList) {
					
				String sCmpntID = sComponentRelID.getCMPNT_RELEASE_DTL_ID();
				max_time_srvcname = DashboardHelper.getMaxTimeScrvName(sCmpntID);			
				maxSrvcNameDetails.put(sCmpntID,
						max_time_srvcname);						
				}
			}
			
			for (String s : componentList) {
				generated_id = contract.getCmpntReleaseDtlId(s,
						releaseMap.get(s), DefaultServerDatabase.getDATABASE(),
						DefaultServerDatabase.getSERVER());
				idStorer.put(s, generated_id);
			}									
		}
		
		model.addObject("componentList", componentList);
		model.addObject("idStorer", idStorer);
		model.addObject("componentRelIDList", componentRelIDList);
		model.addObject("releaseMap", releaseMap);
		model.addObject("requiredBuildDetails", requiredBuildDetails);
		model.addObject("avgBVTTimeDetails", avgBVTTimeDetails);
		model.addObject("maxSrvcNameDetails", maxSrvcNameDetails);
		
		return model;
	}

	@RequestMapping(value = "/buildcomparisonview")
	public ModelAndView buildcomparisonview() {

		ModelAndView model = new ModelAndView("buildcomparisonview");
		List<String> componentList = DashboardHelper.getAllComponents();
		List<CMPNT_RELEASE_DTL_ID> componentRelIDList = null;
		Map<String, String> idStorer = new LinkedHashMap<String, String>();
		Map<String, String> releaseMap = new LinkedHashMap<String, String>();

		releaseMap = DashboardHelper.getLatestReleaseForComponents();
		String generated_id = "";
		List<BUILD_HIST_LATEST_RES> build_hist_latest_res = null;

		Map<String, List<BUILD_HIST_LATEST_RES>> requiredBuildDetails = new LinkedHashMap<String, List<BUILD_HIST_LATEST_RES>>();

		if (componentList != null && !componentList.isEmpty()) {

			String componentName = componentList.get(0);
			componentRelIDList = DashboardHelper.getComponentReleaseDtl(
					componentName, releaseMap.get(componentName));

			if (componentRelIDList != null) {
				for (CMPNT_RELEASE_DTL_ID sComponentRelID : componentRelIDList) {
					build_hist_latest_res = DashboardHelper
							.getRequiredBuildInfoDetails(sComponentRelID
									.getCMPNT_RELEASE_DTL_ID());
					requiredBuildDetails.put(
							sComponentRelID.getCMPNT_RELEASE_DTL_ID(),
							build_hist_latest_res);
				}
			}

			for (String s : componentList) {

				generated_id = contract.getCmpntReleaseDtlId(s,
						releaseMap.get(s), DefaultServerDatabase.getDATABASE(),
						DefaultServerDatabase.getSERVER());
				idStorer.put(s, generated_id);
			}

		}

		model.addObject("componentList", componentList);
		model.addObject("idStorer", idStorer);
		model.addObject("componentRelIDList", componentRelIDList);
		model.addObject("releaseMap", releaseMap);
		model.addObject("requiredBuildDetails", requiredBuildDetails);

		return model;
	}

	@RequestMapping(value = "/getRequiredDb", produces = "application/json")
	public @ResponseBody
	List<Object> getRequiredDbData(
			@RequestParam(value = "cmpreldtl_id") String cmpreldtl_id,
			@RequestParam(value = "database") String database,
			@RequestParam(value = "server") String server) {

		CMPNT_RELEASE_DTL componentReleaseDetails = DashboardHelper
				.getComponentReleaseDtlById(cmpreldtl_id).get(0);

		String cmpnt_gen_id = contract.getCmpntReleaseDtlId(
				componentReleaseDetails.getCMPNT_NAME(),
				componentReleaseDetails.getRELEASE_NMBR(),
				database.toUpperCase(), server.toUpperCase());

		BUILD_HIST dashboardDetails = DashboardHelper
				.getLatestBuildHistDetails(cmpnt_gen_id).get(0);

		List<BUILD_HIST> build_data = DashboardHelper
				.getAllBuildsByComponentReleaseDtlId(cmpnt_gen_id);

		List<Object> returnList = new ArrayList<Object>();

		returnList.add(dashboardDetails);
		returnList.add(build_data);
		returnList.add(cmpnt_gen_id);
		return returnList;
	}

}

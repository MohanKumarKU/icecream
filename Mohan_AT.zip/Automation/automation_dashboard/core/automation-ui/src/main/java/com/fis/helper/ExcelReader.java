package com.fis.helper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelReader 
{

	public static List<List<String>> readExcelData(String component)
	{
		try
		{
			String filename="";
			
			if(component.equalsIgnoreCase("CAPE"))
			{
				filename="CAPE Test Automation Status Report  06122016.xlsx";
			}
			else
				if(component.equalsIgnoreCase("DEPOSITS"))
				{
					filename="DEPOSITS_Regression_Automation_Test Case_Catalog.xlsx";
				}
				else if(component.equalsIgnoreCase("ORG"))
				{
					filename="ORG Test Automation Status Report1.xlsx";
				}
			
	            //Create Workbook instance holding reference to .xlsx file
	            XSSFWorkbook workbook = new XSSFWorkbook(ExcelReader.class.getClassLoader().
	            		getResourceAsStream(filename));
	 
	            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
	           
	            
	            //Get first/desired sheet from the workbook
	            XSSFSheet sheet = workbook.getSheetAt(0);
	 
	            //Iterate through each rows one by one
	            Iterator<Row> rowIterator = sheet.iterator();
			
	            String cellData="";
	            
	            List<List<String>> twodList=new ArrayList<List<String>>();
	            
	            List<String> innerList=null;
	            while (rowIterator.hasNext())
	            {
	            	Row row = rowIterator.next();
	                //For each row, iterate through all the columns
	                Iterator<Cell> cellIterator = row.cellIterator();
	                
	                
	                if(!isRowEmpty(row))
	                {
	                innerList=new ArrayList<String>();
	                while (cellIterator.hasNext()) 
	                {
	                	 Cell cell = cellIterator.next();
	                	 
	                	 cellData=readExcelDatafromcell(cell.getCellType(),cell,evaluator);
	                	 
	                	 if(cellData!=null)
	                	 {
	                		 innerList.add(cellData);
	                	 }
	                	 else
	                		 innerList.add("0");
	                }
	                
	                twodList.add(innerList);
	                }
	                
	            }
	            
	           if(workbook!=null) 
	           workbook.close();
	           
	           
	            return twodList;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	
	public static boolean isRowEmpty(Row row) {
	    for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
	        Cell cell = row.getCell(c);
	        if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK)
	            return false;
	    }
	    return true;
	}
	
	
	
	
	
	
	
	@SuppressWarnings("deprecation")
	public static String  readExcelDatafromcell(int celltype,Cell cell, FormulaEvaluator evaluator)
	{
	

		if (celltype == XSSFCell.CELL_TYPE_STRING)
		{
		     return cell.getStringCellValue();
	    } 
		else if (celltype == XSSFCell.CELL_TYPE_NUMERIC) 
		{
		      return String.valueOf((int)cell.getNumericCellValue());
		       
		} else if (celltype == XSSFCell.CELL_TYPE_BOOLEAN)
		{
		        return String.valueOf(cell.getBooleanCellValue());
		}
		else if (celltype == XSSFCell.CELL_TYPE_FORMULA) 
		{
		        // Re-run based on the formula type
		        evaluator.evaluateFormulaCell(cell);
		       return readExcelDatafromcell(cell.getCachedFormulaResultType(), cell, evaluator);
		}
		
		return null;
	}
	
	

	
}

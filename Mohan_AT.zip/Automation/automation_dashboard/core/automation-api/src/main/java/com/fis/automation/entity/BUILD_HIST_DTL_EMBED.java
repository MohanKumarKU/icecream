package com.fis.automation.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class BUILD_HIST_DTL_EMBED implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String BUILD_NMBR;
	
	private String CMPNT_RELEASE_DTL_ID;
	
	private String TEST_SUITE_NAME;
	
	private String TEST_CASE_NAME;
	
	private String TEST_STEP_NAME;
	

	public String getBUILD_NMBR() {
		return BUILD_NMBR;
	}

	public void setBUILD_NMBR(String bUILD_NMBR) {
		BUILD_NMBR = bUILD_NMBR;
	}

	public String getCMPNT_RELEASE_DTL_ID() {
		return CMPNT_RELEASE_DTL_ID;
	}

	public void setCMPNT_RELEASE_DTL_ID(String cMPNT_RELEASE_DTL_ID) {
		CMPNT_RELEASE_DTL_ID = cMPNT_RELEASE_DTL_ID;
	}

	public String getTEST_SUITE_NAME() {
		return TEST_SUITE_NAME;
	}

	public void setTEST_SUITE_NAME(String tEST_SUITE_NAME) {
		TEST_SUITE_NAME = tEST_SUITE_NAME;
	}

	public String getTEST_CASE_NAME() {
		return TEST_CASE_NAME;
	}

	public void setTEST_CASE_NAME(String tEST_CASE_NAME) {
		TEST_CASE_NAME = tEST_CASE_NAME;
	}

	public String getTEST_STEP_NAME() {
		return TEST_STEP_NAME;
	}

	public void setTEST_STEP_NAME(String tEST_STEP_NAME) {
		TEST_STEP_NAME = tEST_STEP_NAME;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}

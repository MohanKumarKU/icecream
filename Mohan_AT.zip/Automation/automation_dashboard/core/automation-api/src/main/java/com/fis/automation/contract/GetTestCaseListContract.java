package com.fis.automation.contract;

import java.util.Map;

public interface GetTestCaseListContract
{

	/** 
	 * Get List of Testcases...
	 * @param build_no
	 * @param cmpreldtl_id
	 * @return
	 */
	Map<String,String> getTestCaseList(String build_no,String cmpreldtl_id);
	
	
	Map<String,String> getTestCaseStepCounts(String build_no,String cmpreldtl_id);
	
	
}

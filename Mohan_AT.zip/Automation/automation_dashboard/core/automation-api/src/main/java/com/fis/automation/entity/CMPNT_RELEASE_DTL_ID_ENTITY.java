package com.fis.automation.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity(name = "CMPNT_RELEASE_DTL_ID")
public class CMPNT_RELEASE_DTL_ID_ENTITY
{

   @Id
   private String CMPNT_RELEASE_DTL_ID;
   

   public String getCMPNT_RELEASE_DTL_ID()
   {
      return CMPNT_RELEASE_DTL_ID;
   }

   public void setCMPNT_RELEASE_DTL_ID(String cMPNT_RELEASE_DTL_ID)
   {
      CMPNT_RELEASE_DTL_ID = cMPNT_RELEASE_DTL_ID;
   }

}

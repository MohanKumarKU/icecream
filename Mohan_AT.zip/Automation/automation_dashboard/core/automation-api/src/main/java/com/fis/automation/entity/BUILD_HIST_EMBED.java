package com.fis.automation.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class BUILD_HIST_EMBED implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String BUILD_NMBR;
	
	private String CMPNT_RELEASE_DTL_ID;

	public String getBUILD_NMBR() {
		return BUILD_NMBR;
	}

	public void setBUILD_NMBR(String bUILD_NMBR) {
		BUILD_NMBR = bUILD_NMBR;
	}

	public String getCMPNT_RELEASE_DTL_ID() {
		return CMPNT_RELEASE_DTL_ID;
	}

	public void setCMPNT_RELEASE_DTL_ID(String cMPNT_RELEASE_DTL_ID) {
		CMPNT_RELEASE_DTL_ID = cMPNT_RELEASE_DTL_ID;
	}
	
	
	
	
	
}

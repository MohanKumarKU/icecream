package com.fis.automation.controller;

import java.util.List;

import com.fis.automation.bean.BUILD_HIST;
import com.fis.automation.bean.BUILD_HIST_LATEST_RES;
import com.fis.automation.bean.CMPNT_RELEASE_DTL;
import com.fis.automation.bean.CMPNT_RELEASE_DTL_ID;
import com.fis.automation.entity.BUILD_HIST_ENTITY;
import com.fis.automation.entity.BUILD_HIST_LATEST_RES_ENTITY;
import com.fis.automation.entity.CMPNT_RELEASE_DTL_ENTITY;
import com.fis.automation.entity.CMPNT_RELEASE_DTL_ID_ENTITY;
import com.fis.automation.helper.Entity2BeanHelper;
import com.fis.automation.persistance.GetCmpRelDbServerDetailsByIdPersistanceManager;

public class GetCmpRelDbServerDetailsByIdController {

	private static GetCmpRelDbServerDetailsByIdPersistanceManager manager = null;

	private GetCmpRelDbServerDetailsByIdPersistanceManager getManager() {

		if (manager != null)
			return manager;

		return new GetCmpRelDbServerDetailsByIdPersistanceManager();

	}

	public List<CMPNT_RELEASE_DTL> getCmpRelDbServerDetails(String cmpreldtl_id) {
		List<CMPNT_RELEASE_DTL_ENTITY> entityList = getManager()
				.getCmpRelDbServerDetails(cmpreldtl_id);

		// get Bean from Entity...
		return Entity2BeanHelper
				.getCmpRelDbServerDetailsEntity2Bean(entityList);

	}

	public List<BUILD_HIST> getLatestBuildHistDetails(String cmpreldtl_id) {

		List<BUILD_HIST_ENTITY> entityList = getManager()
				.getLatestBuildHistDetails(cmpreldtl_id);

		return Entity2BeanHelper
				.getLatestBuildHistDetailsEntity2Bean(entityList);
	}

	public String getCmpntReleaseDtlId(String component, String release,
			String db, String server) {
		return getManager()
				.getCmpntReleaseDtlId(component, release, db, server);
	}

	public List<BUILD_HIST> getAllBuildsByComponentReleaseDtlId(
			String cmpreldtl_id) {
		List<BUILD_HIST_ENTITY> entityList = getManager()
				.getAllBuildsByComponentReleaseDtlId(cmpreldtl_id);

		return Entity2BeanHelper.getAllBuildsEntity2Bean(entityList);

	}

	public List<String> getAllowedServerDatabaseCombinations(String component,
			String release) {
		return getManager().getAllowedServerDatabaseCombinations(component,
				release);
	}

	public List<CMPNT_RELEASE_DTL_ID> getCmpntReleaseIDDtl(String component, String release) {
		
		List<CMPNT_RELEASE_DTL_ID_ENTITY> entityList = getManager()
				.getCmpntReleaseIDDtl(component,release);

		return Entity2BeanHelper
				.getCmpntReleaseIDDtlEntity2Bean(entityList);
	}

}

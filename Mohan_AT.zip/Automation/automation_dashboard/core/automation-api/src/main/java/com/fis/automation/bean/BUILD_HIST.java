package com.fis.automation.bean;

import java.sql.Date;
import java.sql.Timestamp;

public class BUILD_HIST
{

   private String BUILD_NMBR;

   private String CMPNT_NAME;

   private String RELEASE_NMBR;

   private String DATABASE;

   private String APP_SERVER;

   private String BUILD_STATUS;

   private Date BUILD_DATE;

   private Timestamp BUID_START_TS;

   private Timestamp BUILD_END_TS;

   private String REPORT_PATH;

   private String duration;

   public String getDuration()
   {
      return duration;
   }

   public void setDuration(String duration)
   {
      this.duration = duration;
   }

   private int TEST_CASE_COUNT;

   private int TEST_STEP_COUNT;

   public int getTEST_CASE_COUNT()
   {
      return TEST_CASE_COUNT;
   }

   public void setTEST_CASE_COUNT(int tEST_CASE_COUNT)
   {
      TEST_CASE_COUNT = tEST_CASE_COUNT;
   }

   public int getTEST_STEP_COUNT()
   {
      return TEST_STEP_COUNT;
   }

   public void setTEST_STEP_COUNT(int tEST_STEP_COUNT)
   {
      TEST_STEP_COUNT = tEST_STEP_COUNT;
   }

   public String getBUILD_NMBR()
   {
      return BUILD_NMBR;
   }

   public void setBUILD_NMBR(String bUILD_NMBR)
   {
      BUILD_NMBR = bUILD_NMBR;
   }

   public String getCMPNT_NAME()
   {
      return CMPNT_NAME;
   }

   public void setCMPNT_NAME(String cMPNT_NAME)
   {
      CMPNT_NAME = cMPNT_NAME;
   }

   public String getRELEASE_NMBR()
   {
      return RELEASE_NMBR;
   }

   public void setRELEASE_NMBR(String rELEASE_NMBR)
   {
      RELEASE_NMBR = rELEASE_NMBR;
   }

   public String getDATABASE()
   {
      return DATABASE;
   }

   public void setDATABASE(String dATABASE)
   {
      DATABASE = dATABASE;
   }

   public String getAPP_SERVER()
   {
      return APP_SERVER;
   }

   public void setAPP_SERVER(String aPP_SERVER)
   {
      APP_SERVER = aPP_SERVER;
   }

   public String getBUILD_STATUS()
   {
      return BUILD_STATUS;
   }

   public void setBUILD_STATUS(String bUILD_STATUS)
   {
      BUILD_STATUS = bUILD_STATUS;
   }

   public Date getBUILD_DATE()
   {
      return BUILD_DATE;
   }

   public void setBUILD_DATE(Date bUILD_DATE)
   {
      BUILD_DATE = bUILD_DATE;
   }

   public Timestamp getBUID_START_TS()
   {
      return BUID_START_TS;
   }

   public void setBUID_START_TS(Timestamp bUID_START_TS)
   {
      BUID_START_TS = bUID_START_TS;
   }

   public Timestamp getBUILD_END_TS()
   {
      return BUILD_END_TS;
   }

   public void setBUILD_END_TS(Timestamp bUILD_END_TS)
   {
      BUILD_END_TS = bUILD_END_TS;
   }

   public String getREPORT_PATH()
   {
      return REPORT_PATH;
   }

   public void setREPORT_PATH(String rEPORT_PATH)
   {
      REPORT_PATH = rEPORT_PATH;
   }

}

package com.fis.automation.persistance;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import com.fis.automation.bean.BUILD_HIST;
import com.fis.automation.durationhandler.DurationStorer;
import com.fis.automation.entity.BUILD_HIST_ENTITY;
import com.fis.automation.entity.CMPNT_RELEASE_DTL_ENTITY;
import com.fis.automation.entity.CMPNT_RELEASE_DTL_ID_ENTITY;
import com.fis.automation.sessionfact.GetHibernateSessionFactory;

public class GetCmpRelDbServerDetailsByIdPersistanceManager 
{

	SQLQuery sqlquery=null;
	
	public List<CMPNT_RELEASE_DTL_ENTITY> getCmpRelDbServerDetails(String cmpreldtl_id) 
	{
		
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		sqlquery=session.createSQLQuery("select * from CMPNT_RELEASE_DTL where CMPNT_RELEASE_DTL_ID=?");
		sqlquery.setParameter(0, cmpreldtl_id);
		
		sqlquery.addEntity(CMPNT_RELEASE_DTL_ENTITY.class);
		
		
		return sqlquery.list();
		
	}
	
	public List<CMPNT_RELEASE_DTL_ID_ENTITY> getCmpntReleaseIDDtl(String component, String release) 
	{
		
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		sqlquery=session.createSQLQuery("select * from CMPNT_RELEASE_DTL where CMPNT_NAME=? and RELEASE_NMBR=? order by CMPNT_RELEASE_DTL_ID");
		sqlquery.setParameter(0, component);
		sqlquery.setParameter(1, release);
		
		sqlquery.addEntity(CMPNT_RELEASE_DTL_ID_ENTITY.class);		
		
		return sqlquery.list();
		
	}

	

	public List<BUILD_HIST_ENTITY> getLatestBuildHistDetails(String cmpreldtl_id)
	{
	
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		
		if(DurationStorer.getEndDate()!=null || DurationStorer.getStartDate()!=null)
		{
		
			sqlquery=session.createSQLQuery("select * from BUILD_HIST where BUID_START_TS=(select max(BUID_START_TS) from BUILD_HIST where CMPNT_RELEASE_DTL_ID=? and BUILD_DATE>=? and BUILD_DATE<=? and BUILD_STATUS IN('Y','N'))");
			
			sqlquery.setParameter(0, cmpreldtl_id);
			
			sqlquery.setParameter(1,DurationStorer.getStartDate());
			
			sqlquery.setParameter(2,DurationStorer.getEndDate());			

			sqlquery.addEntity(BUILD_HIST_ENTITY.class);			
			
		}else
		{
		sqlquery=session.createSQLQuery("select * from BUILD_HIST where BUID_START_TS=(select max(BUID_START_TS) from BUILD_HIST where CMPNT_RELEASE_DTL_ID=? and BUILD_STATUS IN('Y','N'))");
		
		sqlquery.setParameter(0, cmpreldtl_id);
		
		sqlquery.addEntity(BUILD_HIST_ENTITY.class);
		
		}			
		return sqlquery.list();		
	}
	
	
	
	public int getTeststepCount(String build_no,String cmprelDbserverid)
	{
		
		String query="select count(*) from BUILD_HIST_DTL where BUILD_NMBR=? and CMPNT_RELEASE_DTL_ID=?";

		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		SQLQuery sqlquery=session.createSQLQuery(query);
		
		sqlquery.setParameter(0, build_no);
		sqlquery.setParameter(1, cmprelDbserverid);
		
		return Integer.parseInt(sqlquery.list().get(0).toString());
		

	}
	
	
	public int getTestcaseCount(String build_no, String cmprelDbserverid) 
	{
		String query="select count(*) from (select TEST_CASE_NAME from BUILD_HIST_DTL  "
				+ " where BUILD_NMBR=? and CMPNT_RELEASE_DTL_ID=? group by TEST_CASE_NAME)";

		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		SQLQuery sqlquery=session.createSQLQuery(query);
		
		sqlquery.setParameter(0, build_no);
		sqlquery.setParameter(1, cmprelDbserverid);
		
		return Integer.parseInt(sqlquery.list().get(0).toString());
		
	}

	public String getCmpntReleaseDtlId(String component, String release,
			String db, String server) 
	{
		
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		sqlquery=session.createSQLQuery("select CMPNT_RELEASE_DTL_ID from CMPNT_RELEASE_DTL where CMPNT_NAME=? and RELEASE_NMBR=? and DBMS_CL=? and APPS_CL=?");
		
		sqlquery.setParameter(0, component);
		sqlquery.setParameter(1, release);
		sqlquery.setParameter(2, db);
		sqlquery.setParameter(3, server);
		
		return (String) sqlquery.uniqueResult();
		
	}

	public List<BUILD_HIST_ENTITY> getAllBuildsByComponentReleaseDtlId(
			String cmpreldtl_id)
	{
		
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		if(DurationStorer.getEndDate()!=null || DurationStorer.getStartDate()!=null)
		{
		
			sqlquery=session.createSQLQuery("select * from BUILD_HIST where CMPNT_RELEASE_DTL_ID=? and BUILD_DATE>=? and BUILD_DATE<=? and BUILD_STATUS IN('Y','N') order by BUID_START_TS desc");
			
			sqlquery.setParameter(0, cmpreldtl_id);
			
			sqlquery.setParameter(1,DurationStorer.getStartDate());
			
			sqlquery.setParameter(2,DurationStorer.getEndDate());
			
			sqlquery.addEntity(BUILD_HIST_ENTITY.class);
				
		}	
			
		else
		{
		sqlquery=session.createSQLQuery("select * from BUILD_HIST where CMPNT_RELEASE_DTL_ID=? and BUILD_STATUS IN('Y','N') order by BUID_START_TS desc");
		
		sqlquery.setParameter(0, cmpreldtl_id);
		sqlquery.addEntity(BUILD_HIST_ENTITY.class);
		}
		
		return sqlquery.list();
	}

	@SuppressWarnings("unchecked")
	public List<String> getAllowedServerDatabaseCombinations(String component,
			String release)
	{
		
		Session session=GetHibernateSessionFactory.getHibernateSession();

		sqlquery=session.createSQLQuery("select concat(DBMS_CL,APPS_CL) from CMPNT_RELEASE_DTL where CMPNT_NAME=? and RELEASE_NMBR=? group by DBMS_CL,APPS_CL order by CASE WHEN concat(DBMS_CL,APPS_CL) like '%ORA%' THEN '1' WHEN concat(DBMS_CL,APPS_CL) like '%DB2%' THEN '2' WHEN concat(DBMS_CL,APPS_CL) like '%POSTGRES%' THEN '3' ELSE concat(DBMS_CL,APPS_CL) END ASC");
		
		sqlquery.setParameter(0, component);
		sqlquery.setParameter(1,release);
		
		return (List<String>)sqlquery.list();
		
	}
	
	
	
	
	
	

}

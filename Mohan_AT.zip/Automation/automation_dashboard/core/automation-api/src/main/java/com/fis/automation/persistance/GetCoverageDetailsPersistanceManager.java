package com.fis.automation.persistance;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import com.fis.automation.entity.BUILD_COVERAGE_ENTITY;
import com.fis.automation.sessionfact.GetHibernateSessionFactory;

public class GetCoverageDetailsPersistanceManager 
{

	SQLQuery sqlquery=null;
	
	
	@SuppressWarnings("unchecked")
	public List<String> getAllNonAutomatedServices(String build_no,String cmpreldtl_id) 
	{
		
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		String query="select SRVC_OPRTN_NAME from BUILD_FNCTNL_COVERAGE where BUILD_NMBR=? and CMPNT_RELEASE_DTL_ID=? and TEST_CASE_CNT=0";	
		
		SQLQuery sqlquery=session.createSQLQuery(query); 
		
		sqlquery.setParameter(0, build_no);
		sqlquery.setParameter(1, cmpreldtl_id);

		return (List<String>)sqlquery.list();
		
	}


	@SuppressWarnings("unchecked")
	public int[] getAutomatedPercentage(String build_no, String cmpreldtl_id) 
	{
		
		
		
		int resultArray[]=new int[2];
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		
		String query="select count(*) from BUILD_FNCTNL_COVERAGE where BUILD_NMBR=? and CMPNT_RELEASE_DTL_ID=? and TEST_CASE_CNT=0";	
		
		SQLQuery sqlquery=session.createSQLQuery(query);	
		
		sqlquery.setParameter(0, build_no);
		sqlquery.setParameter(1, cmpreldtl_id);
		
		
		resultArray[0]=Integer.parseInt(((List<BigDecimal>)sqlquery.list()).get(0).toString());
		
		query="select count(*) from BUILD_FNCTNL_COVERAGE where BUILD_NMBR=? and CMPNT_RELEASE_DTL_ID=? and TEST_CASE_CNT>0";	
		
		sqlquery=session.createSQLQuery(query);
		
		sqlquery.setParameter(0, build_no);
		sqlquery.setParameter(1, cmpreldtl_id);
		
		resultArray[1]=Integer.parseInt(((List<BigDecimal>)sqlquery.list()).get(0).toString());
		
		
		return resultArray;

	}


	public List<BUILD_COVERAGE_ENTITY> getAutomatedTestcaseInfo(String build_no,
			String cmpreldtl_id) 
	{
		
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		String query="Select * from BUILD_FNCTNL_COVERAGE where BUILD_NMBR=? and CMPNT_RELEASE_DTL_ID=? and TEST_CASE_CNT>0";
		
		SQLQuery sqlquery=session.createSQLQuery(query);

		sqlquery.addEntity(BUILD_COVERAGE_ENTITY.class);
		
		sqlquery.setParameter(0, build_no);
		sqlquery.setParameter(1, cmpreldtl_id);
		
		@SuppressWarnings("unchecked")
		List<BUILD_COVERAGE_ENTITY> s=(List<BUILD_COVERAGE_ENTITY>)sqlquery.list();
		
		if(s!=null)
		return s;
	
		return null;
	}

}

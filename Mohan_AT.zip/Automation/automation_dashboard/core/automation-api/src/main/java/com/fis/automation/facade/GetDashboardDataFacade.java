package com.fis.automation.facade;

import java.util.List;
import java.util.Map;

import com.fis.automation.contract.GetDashboardDataContract;
import com.fis.automation.controller.GetDashboardDataController;

public class GetDashboardDataFacade implements GetDashboardDataContract {

	
	private static GetDashboardDataController controller=null;
	
	private GetDashboardDataController getController()
	{
		
		if(controller!=null) return controller;
		
		return new GetDashboardDataController();
		
	}
	
	public List<String> getAllComponents() 
	{
		return getController().getAllComponents();
	}

	public Map<String, String> getLatestReleaseForComponents() 
	{
			
		return getController().getLatestReleaseForComponents();
	}

	public String getPreviousReleaseForComponents(
			String cmpnt_name, String release_no) {
		return getController().getPreviousReleaseForComponents(cmpnt_name,release_no);
	}

}

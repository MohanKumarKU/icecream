package com.fis.automation.bean;

import java.sql.Date;
import java.sql.Timestamp;

public class BUILD_HIST_DTL 
{

	private String BUILD_NMBR;
	
	private String CMPNT_RELEASE_DTL_ID;
	
	public String getBUILD_NMBR() {
		return BUILD_NMBR;
	}

	public void setBUILD_NMBR(String bUILD_NMBR) {
		BUILD_NMBR = bUILD_NMBR;
	}

	public String getCMPNT_RELEASE_DTL_ID() {
		return CMPNT_RELEASE_DTL_ID;
	}

	public void setCMPNT_RELEASE_DTL_ID(String cMPNT_RELEASE_DTL_ID) {
		CMPNT_RELEASE_DTL_ID = cMPNT_RELEASE_DTL_ID;
	}

	public String getTEST_SUITE_NAME() {
		return TEST_SUITE_NAME;
	}

	public void setTEST_SUITE_NAME(String tEST_SUITE_NAME) {
		TEST_SUITE_NAME = tEST_SUITE_NAME;
	}

	public String getTEST_CASE_NAME() {
		return TEST_CASE_NAME;
	}

	public void setTEST_CASE_NAME(String tEST_CASE_NAME) {
		TEST_CASE_NAME = tEST_CASE_NAME;
	}

	public String getTEST_STEP_NAME() {
		return TEST_STEP_NAME;
	}

	public void setTEST_STEP_NAME(String tEST_STEP_NAME) {
		TEST_STEP_NAME = tEST_STEP_NAME;
	}

	public String getFNCTNL_ITEM_INDCTR() {
		return FNCTNL_ITEM_INDCTR;
	}

	public void setFNCTNL_ITEM_INDCTR(String fNCTNL_ITEM_INDCTR) {
		FNCTNL_ITEM_INDCTR = fNCTNL_ITEM_INDCTR;
	}

	public String getBUILD_STATUS() {
		return BUILD_STATUS;
	}

	public void setBUILD_STATUS(String bUILD_STATUS) {
		BUILD_STATUS = bUILD_STATUS;
	}

	public Date getBATCH_EXEC_DATE() {
		return BATCH_EXEC_DATE;
	}

	public void setBATCH_EXEC_DATE(Date bATCH_EXEC_DATE) {
		BATCH_EXEC_DATE = bATCH_EXEC_DATE;
	}

	public String getBUILD_FAILED_REASN() {
		return BUILD_FAILED_REASN;
	}

	public void setBUILD_FAILED_REASN(String bUILD_FAILED_REASN) {
		BUILD_FAILED_REASN = bUILD_FAILED_REASN;
	}

	public Date getBUILD_DATE() {
		return BUILD_DATE;
	}

	public void setBUILD_DATE(Date bUILD_DATE) {
		BUILD_DATE = bUILD_DATE;
	}

	public Timestamp getSTART_TS() {
		return START_TS;
	}

	public void setSTART_TS(Timestamp sTART_TS) {
		START_TS = sTART_TS;
	}

	public Timestamp getEND_TS() {
		return END_TS;
	}

	public void setEND_TS(Timestamp eND_TS) {
		END_TS = eND_TS;
	}
	

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}



	private String TEST_SUITE_NAME;
	
	private String TEST_CASE_NAME;
	
	private String TEST_STEP_NAME;
	
	private String FNCTNL_ITEM_INDCTR;
	
	private String BUILD_STATUS;
	
	private Date BATCH_EXEC_DATE;
	
	private String BUILD_FAILED_REASN;

	private Date BUILD_DATE;
	
	private Timestamp START_TS;
	
	private Timestamp END_TS;
	
	private String TEST_CASE_DESC;
	
	private String TEST_STEP_SCREENSHOT_NAME;
	
	private String WORD_DOC_PATH;
	
	private String duration;
	
	private String SVN_PATH;

   public String getSVN_PATH()
   {
      return SVN_PATH;
   }

   public void setSVN_PATH(String sVN_PATH)
   {
      SVN_PATH = sVN_PATH;
   }

public String getTEST_CASE_DESC() {
	return TEST_CASE_DESC;
}

public void setTEST_CASE_DESC(String tEST_CASE_DESC) {
	TEST_CASE_DESC = tEST_CASE_DESC;
}

public String getTEST_STEP_SCREENSHOT_NAME() {
	return TEST_STEP_SCREENSHOT_NAME;
}

public void setTEST_STEP_SCREENSHOT_NAME(String tEST_STEP_SCREENSHOT_NAME) {
	TEST_STEP_SCREENSHOT_NAME = tEST_STEP_SCREENSHOT_NAME;
}

public String getWORD_DOC_PATH() {
	return WORD_DOC_PATH;
}

public void setWORD_DOC_PATH(String wORD_DOC_PATH) {
	WORD_DOC_PATH = wORD_DOC_PATH;
}
	
	
}

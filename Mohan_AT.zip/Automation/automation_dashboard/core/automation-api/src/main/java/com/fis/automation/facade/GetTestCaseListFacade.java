package com.fis.automation.facade;

import java.util.Map;

import com.fis.automation.contract.GetTestCaseListContract;
import com.fis.automation.controller.GetTestCaseListController;

public class GetTestCaseListFacade implements GetTestCaseListContract
{

private static GetTestCaseListController controller=null;
	
	private GetTestCaseListController getController()
	{
		
		if(controller!=null) return controller;
		
		return new GetTestCaseListController();
		
	}

	public Map<String, String> getTestCaseList(String build_no,
			String cmpreldtl_id) 
	{
	
		return getController().getTestCaseList(build_no,cmpreldtl_id);
	}

	public Map<String, String> getTestCaseStepCounts(String build_no,
			String cmpreldtl_id)
	{
		return getController().getTestCaseStepCounts(build_no,cmpreldtl_id);
	}
	
	
}

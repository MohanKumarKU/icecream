package com.fis.automation.contract;

import java.util.List;

import com.fis.automation.bean.BUILD_HIST;
import com.fis.automation.bean.BUILD_HIST_AVG_TIME;
import com.fis.automation.bean.BUILD_HIST_DTL;
import com.fis.automation.bean.BUILD_HIST_LATEST_RES;
import com.fis.automation.bean.MAX_TIME_SRVCNAME;

public interface GetRequiredBuildContract 
{

		List<BUILD_HIST> getRequiredBuildInformation(String build_no,String cmpreldtl_id);
		
		/** 
		 * get recent 5 Builds by Component Release Detail Id
		 */
		
		List<BUILD_HIST_LATEST_RES> getRequiredBuildInfoDetails(String cmpreldtl_id);
		
			
		List<BUILD_HIST_DTL>  getAccordionContent(String build_no,String testcasename,String cmpreldtl_id,String component);
		
		/** To get the Avg Time for all the components*/
		
		List<BUILD_HIST_AVG_TIME> getAvgBVTTime(String component) ;
		
		/** To get the Max Time taken Services/API List by Component Release Detail Id*/
		
		List<MAX_TIME_SRVCNAME> getMaxTimeScrvName(String cmpreldtl_id) ;
		
}

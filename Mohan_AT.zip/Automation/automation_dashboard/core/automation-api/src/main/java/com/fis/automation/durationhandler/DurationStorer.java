package com.fis.automation.durationhandler;

import java.sql.Date;

public class DurationStorer
{

	private static Date startDate=null;
	
	private static Date endDate=null;


	public static Date getStartDate() {
		return startDate;
	}

	public static void setStartDate(Date startDate) {
		DurationStorer.startDate = startDate;
	}

	public static Date getEndDate() {
		return endDate;
	}

	public static void setEndDate(Date endDate) {
		DurationStorer.endDate = endDate;
	}

}

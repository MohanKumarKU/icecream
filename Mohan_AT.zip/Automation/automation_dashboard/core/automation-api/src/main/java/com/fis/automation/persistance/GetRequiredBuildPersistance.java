package com.fis.automation.persistance;

import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import com.fis.automation.bean.BUILD_HIST_DTL;
import com.fis.automation.entity.BUILD_HIST_AVG_TIME_ENTITY;
import com.fis.automation.entity.BUILD_HIST_DTL_ENTITY;
import com.fis.automation.entity.BUILD_HIST_ENTITY;
import com.fis.automation.entity.BUILD_HIST_LATEST_RES_ENTITY;
import com.fis.automation.entity.CMPNT_RELEASE_DTL_ID_ENTITY;
import com.fis.automation.entity.MAX_TIME_SRVCNAME_ENTITY;
import com.fis.automation.sessionfact.GetHibernateSessionFactory;

public class GetRequiredBuildPersistance {

	SQLQuery sqlquery = null;

	public List<BUILD_HIST_ENTITY> getRequiredBuildInformation(String build_no,
			String cmpreldtl_id) {

		Session session = GetHibernateSessionFactory.getHibernateSession();

		sqlquery = session
				.createSQLQuery("select * from BUILD_HIST where CMPNT_RELEASE_DTL_ID=? and BUILD_NMBR=?");

		sqlquery.setParameter(0, cmpreldtl_id);
		sqlquery.setParameter(1, build_no);

		sqlquery.addEntity(BUILD_HIST_ENTITY.class);

		return sqlquery.list();
	}

	public List<BUILD_HIST_LATEST_RES_ENTITY> getRequiredBuildInfoDetails(
			String cmpreldtl_id) {

		Session session = GetHibernateSessionFactory.getHibernateSession();

		sqlquery=session.createSQLQuery("Select * from BUILD_HIST t2 where t2.buid_start_ts = (select max(buid_start_ts) from BUILD_HIST t1 "
				+ "where t1.BUILD_DATE = t2.BUILD_DATE and t1.CMPNT_RELEASE_DTL_ID=? and t1.Build_Status in('Y','N')) "
				+ "and Build_Date >= ( Select max(Build_Date)-6 from  BUILD_HIST where CMPNT_RELEASE_DTL_ID=? ) "
				+ "order by t2.Build_Date asc");

		sqlquery.setParameter(0, cmpreldtl_id);
		sqlquery.setParameter(1, cmpreldtl_id);

		sqlquery.addEntity(BUILD_HIST_LATEST_RES_ENTITY.class);

		return sqlquery.list();
	}

	public List<BUILD_HIST_DTL_ENTITY> getAccordionContent(String build_no,
			String testcasename, String cmpreldtl_id) {

		Session session = GetHibernateSessionFactory.getHibernateSession();

		String query = "select * from BUILD_HIST_DTL where BUILD_NMBR=? and TEST_CASE_NAME=? and CMPNT_RELEASE_DTL_ID=? order by START_TS";

		SQLQuery sqlquery = session.createSQLQuery(query);

		sqlquery.addEntity(BUILD_HIST_DTL_ENTITY.class);

		sqlquery.setParameter(0, build_no);
		sqlquery.setParameter(1, testcasename);
		sqlquery.setParameter(2, cmpreldtl_id);

		@SuppressWarnings("unchecked")
		List<BUILD_HIST_DTL_ENTITY> testcaseContent = (List<BUILD_HIST_DTL_ENTITY>) sqlquery
				.list();

		return testcaseContent;

	}
	
	public List<BUILD_HIST_AVG_TIME_ENTITY> getAvgBVTTime(String component) 
	{
		
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		sqlquery = session.createSQLQuery("select CMPNT_RELEASE_DTL_ID, TRUNC(avg (to_date(to_char( BUILD_END_TS, 'DD-MM-YYYY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS')  - to_date(to_char (BUID_START_TS,'DD-MM-YYYY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS'))*24, 2) As AVGTIME"
				+" from build_hist d where d.BUILD_END_TS is not null"
				+" and d.Build_Status in ('Y', 'N')" 
				+" and d.CMPNT_RELEASE_DTL_ID in (Select CMPNT_RELEASE_DTL_ID from CMPNT_RELEASE_DTL where CMPNT_NAME = ? and RELEASE_NMBR =(Select max(RELEASE_NMBR) from CMPNT_RELEASE_DTL where CMPNT_NAME = ?))"
				+" and d.Build_Date >= ( Select max(Build_Date)-6 from  build_hist e where d.CMPNT_RELEASE_DTL_ID = e.CMPNT_RELEASE_DTL_ID ) "
				+ " group by CMPNT_RELEASE_DTL_ID order by CASE WHEN CMPNT_RELEASE_DTL_ID like '%OR' THEN '1' WHEN CMPNT_RELEASE_DTL_ID like '%D2' THEN '2' WHEN CMPNT_RELEASE_DTL_ID like '%PG' THEN '3' ELSE CMPNT_RELEASE_DTL_ID END ASC");
		
		sqlquery.setParameter(0, component);
		sqlquery.setParameter(1, component);
		
		sqlquery.addEntity(BUILD_HIST_AVG_TIME_ENTITY.class);		
		
		return sqlquery.list();
		
	}
	
	public List<MAX_TIME_SRVCNAME_ENTITY> getMaxTimeScrvName(String cmpreldtl_id) 
	{
		
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		sqlquery = session.createSQLQuery("SELECT * FROM ( SELECT BHD.SRVC_NAME, BHD.CMPNT_RELEASE_DTL_ID,  COUNT(BHD.SRVC_NAME) AS COUNT_SRVCNAME, "
				+ "TRUNC(AVG (TO_DATE(TO_CHAR( BHD.END_TS, 'DD-MM-YYYY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS')  - TO_DATE(TO_CHAR (BHD.START_TS,'DD-MM-YYYY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS'))*24*60*60*1000,2) AS AVGTIME_MSEC, "
				+ "TRUNC(SUM (TO_DATE(TO_CHAR( BHD.END_TS, 'DD-MM-YYYY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS')  - TO_DATE(TO_CHAR (BHD.START_TS,'DD-MM-YYYY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS'))*24*60*60,2) AS TOTALTIME_SEC "
				+ "FROM BUILD_HIST_DTL  BHD WHERE BHD.FNCTNL_ITEM_INDCTR = 'S' AND BHD.SRVC_NAME IS NOT NULL  "
				+ "AND BHD.BUILD_STATUS IN ('Y', 'X') AND BHD.CMPNT_RELEASE_DTL_ID =? "
				+ "AND BHD.BUILD_DATE >= ( SELECT MAX(BHDX.BUILD_DATE)-6 AS BUILDDATE FROM  BUILD_HIST_DTL BHDX WHERE BHDX.CMPNT_RELEASE_DTL_ID=? )"
				+ " GROUP BY BHD.SRVC_NAME, BHD.CMPNT_RELEASE_DTL_ID ORDER BY COUNT_SRVCNAME DESC )  WHERE ROWNUM < 6");
		
		sqlquery.setParameter(0, cmpreldtl_id);
		sqlquery.setParameter(1, cmpreldtl_id);
		
		sqlquery.addEntity(MAX_TIME_SRVCNAME_ENTITY.class);		
		
		return sqlquery.list();
		
	}

}

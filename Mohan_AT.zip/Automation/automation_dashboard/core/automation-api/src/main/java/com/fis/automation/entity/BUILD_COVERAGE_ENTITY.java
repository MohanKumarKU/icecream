package com.fis.automation.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="BUILD_FNCTNL_COVERAGE")
@Table
public class BUILD_COVERAGE_ENTITY  implements Serializable
{
	
	@EmbeddedId
	BUILD_HIST_EMBED embedId;
	
	@Id
	private String SRVC_OPRTN_NAME;
	
	private String TEST_CASE_CNT;
	
	private String TEST_STEP_CNT;

	public BUILD_HIST_EMBED getEmbedId() {
		return embedId;
	}

	public void setEmbedId(BUILD_HIST_EMBED embedId) {
		this.embedId = embedId;
	}

	public String getSRVC_OPRTN_NAME() {
		return SRVC_OPRTN_NAME;
	}

	public void setSRVC_OPRTN_NAME(String sRVC_OPRTN_NAME) {
		SRVC_OPRTN_NAME = sRVC_OPRTN_NAME;
	}

	public String getTEST_CASE_CNT() {
		return TEST_CASE_CNT;
	}

	public void setTEST_CASE_CNT(String tEST_CASE_CNT) {
		TEST_CASE_CNT = tEST_CASE_CNT;
	}

	public String getTEST_STEP_CNT() {
		return TEST_STEP_CNT;
	}

	public void setTEST_STEP_CNT(String tEST_STEP_CNT) {
		TEST_STEP_CNT = tEST_STEP_CNT;
	}
	
	
	
	
}

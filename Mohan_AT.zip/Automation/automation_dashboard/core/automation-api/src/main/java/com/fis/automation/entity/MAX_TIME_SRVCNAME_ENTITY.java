package com.fis.automation.entity;


import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity(name = "MAX_TIME_SRVCNAME")
@Table
public class MAX_TIME_SRVCNAME_ENTITY {
	
	@EmbeddedId
	MAX_TIME_SRVCNAME_EMBED embedId;

	/*private String TEST_SUITE_NAME;

	private String TEST_CASE_NAME;

	private String TEST_STEP_NAME;
	
	private Date Build_Date;*/

	private String COUNT_SRVCNAME;

	private String AVGTIME_MSEC;

	private String TOTALTIME_SEC;
	

	/*public String getTEST_SUITE_NAME() {
		return TEST_SUITE_NAME;
	}

	public void setTEST_SUITE_NAME(String tEST_SUITE_NAME) {
		TEST_SUITE_NAME = tEST_SUITE_NAME;
	}

	public String getTEST_CASE_NAME() {
		return TEST_CASE_NAME;
	}

	public void setTEST_CASE_NAME(String tEST_CASE_NAME) {
		TEST_CASE_NAME = tEST_CASE_NAME;
	}

	public String getTEST_STEP_NAME() {
		return TEST_STEP_NAME;
	}

	public void setTEST_STEP_NAME(String tEST_STEP_NAME) {
		TEST_STEP_NAME = tEST_STEP_NAME;
	}	

	public Date getBuild_Date() {
		return Build_Date;
	}

	public void setBuild_Date(Date build_Date) {
		Build_Date = build_Date;
	}*/
	
	public String getCOUNT_SRVCNAME() {
		return COUNT_SRVCNAME;
	}

	public void setCOUNT_SRVCNAME(String cOUNT_SRVCNAME) {
		COUNT_SRVCNAME = cOUNT_SRVCNAME;
	}

	public String getAVGTIME_MSEC() {
		return AVGTIME_MSEC;
	}

	public void setAVGTIME_MSEC(String aVGTIME_MSEC) {
		AVGTIME_MSEC = aVGTIME_MSEC;
	}

	public String getTOTALTIME_SEC() {
		return TOTALTIME_SEC;
	}

	public void setTOTALTIME_SEC(String tOTALTIME_SEC) {
		TOTALTIME_SEC = tOTALTIME_SEC;
	}
	
	public MAX_TIME_SRVCNAME_EMBED getEmbedId() {
		return embedId;
	}

	public void setEmbedId(MAX_TIME_SRVCNAME_EMBED embedId) {
		this.embedId = embedId;
	}

}

package com.fis.automation.controller;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import com.fis.automation.bean.BUILD_HIST;
import com.fis.automation.bean.BUILD_HIST_AVG_TIME;
import com.fis.automation.bean.BUILD_HIST_DTL;
import com.fis.automation.bean.BUILD_HIST_LATEST_RES;
import com.fis.automation.bean.MAX_TIME_SRVCNAME;
import com.fis.automation.entity.BUILD_HIST_AVG_TIME_ENTITY;
import com.fis.automation.entity.BUILD_HIST_DTL_ENTITY;
import com.fis.automation.entity.BUILD_HIST_ENTITY;
import com.fis.automation.entity.BUILD_HIST_LATEST_RES_ENTITY;
import com.fis.automation.entity.MAX_TIME_SRVCNAME_ENTITY;
import com.fis.automation.helper.Entity2BeanHelper;
import com.fis.automation.persistance.GetRequiredBuildPersistance;


public class GetRequiredBuildController 
{

private static GetRequiredBuildPersistance manager=null;
	
	private GetRequiredBuildPersistance getManager()
	{
		
		if(manager!=null) return manager;		
		return new GetRequiredBuildPersistance();
		
	}	
	
	
	public List<BUILD_HIST> getRequiredBuildInformation(String build_no,
			String cmpreldtl_id) 
	{
		List<BUILD_HIST_ENTITY> entityList= getManager().getRequiredBuildInformation(build_no,cmpreldtl_id);
		
		return Entity2BeanHelper.getLatestBuildHistDetailsEntity2Bean(entityList);
	}
	
	public List<BUILD_HIST_LATEST_RES> getRequiredBuildInfoDetails(String cmpreldtl_id) 
	{
		List<BUILD_HIST_LATEST_RES_ENTITY> entityList= getManager().getRequiredBuildInfoDetails(cmpreldtl_id);
		
		return Entity2BeanHelper.getRequiredBuildInfoDetailsEntity2Bean(entityList);
	}

	public List<BUILD_HIST_DTL> getAccordionContent(String build_no,
			String testcasename, String cmpreldtl_id,String component)
	{
	
		List<BUILD_HIST_DTL_ENTITY> entityList=getManager().getAccordionContent(build_no,testcasename,cmpreldtl_id);
		
		String svn_path=getPropertiesData(component);
		
		System.out.println(svn_path);
		
		return Entity2BeanHelper.BuildHistDetailEntity2Bean(entityList,svn_path);
	}
	
	
	public static String getPropertiesData(String key)
   {

      Properties properties = new Properties();
      try
      {
         properties.load(GetRequiredBuildController.class.getClassLoader()
            .getResourceAsStream("datatool.properties"));

         return properties.getProperty(key.toLowerCase()+"link");

      }
      catch (NullPointerException e)
      {
         e.printStackTrace();
         return "PROPERTIES_FILE_NOT_FOUND";
      }

      catch (IOException e)
      {
         e.printStackTrace();

      }

      return null;
   }
	
	public List<BUILD_HIST_AVG_TIME> getAvgBVTTime(String component) 
	{
		List<BUILD_HIST_AVG_TIME_ENTITY> entityList= getManager().getAvgBVTTime(component);
		
		return Entity2BeanHelper.getAvgBVTTimeEntity2Bean(entityList);
	}
	
	public List<MAX_TIME_SRVCNAME> getMaxTimeScrvName(String cmpreldtl_id) 
	{
		List<MAX_TIME_SRVCNAME_ENTITY> entityList= getManager().getMaxTimeScrvName(cmpreldtl_id);
		
		return Entity2BeanHelper.getMaxTimeScrvNameEntity2Bean(entityList);
	}

}

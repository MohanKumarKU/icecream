package com.fis.automation.contract;

import java.util.List;
import java.util.Map;

public interface GetDashboardDataContract {

	/**
	 * get List of Components....
	 * 
	 * @return
	 */
	List<String> getAllComponents();

	Map<String, String> getLatestReleaseForComponents();

	String getPreviousReleaseForComponents(String cmpnt_name, String release_no);
}

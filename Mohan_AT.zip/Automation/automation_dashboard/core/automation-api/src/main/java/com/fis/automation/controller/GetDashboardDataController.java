package com.fis.automation.controller;

import java.util.List;
import java.util.Map;

import com.fis.automation.persistance.GetDashboardDataPersistance;

public class GetDashboardDataController {

	private static GetDashboardDataPersistance manager = null;

	private GetDashboardDataPersistance getManager() {

		if (manager != null)
			return manager;

		return new GetDashboardDataPersistance();

	}

	public List<String> getAllComponents() {
		return getManager().getAllComponents();
	}

	public Map<String, String> getLatestReleaseForComponents() {
		return getManager().getLatestReleaseForComponents();
	}

	public String getPreviousReleaseForComponents(String cmpnt_name,
			String release_no) {
		return getManager().getPreviousReleaseForComponents(cmpnt_name,
				release_no);
	}

}

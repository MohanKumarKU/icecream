package com.fis.automation.entity;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity(name="BUILD_HIST_DTL")
@Table
public class BUILD_HIST_DTL_ENTITY
{
	
	@EmbeddedId
	BUILD_HIST_DTL_EMBED embedId;
	
	public BUILD_HIST_DTL_EMBED getEmbedId() {
		return embedId;
	}

	public void setEmbedId(BUILD_HIST_DTL_EMBED embedId) {
		this.embedId = embedId;
	}

	
	public String getFNCTNL_ITEM_INDCTR() {
		return FNCTNL_ITEM_INDCTR;
	}

	public void setFNCTNL_ITEM_INDCTR(String fNCTNL_ITEM_INDCTR) {
		FNCTNL_ITEM_INDCTR = fNCTNL_ITEM_INDCTR;
	}

	public String getBUILD_STATUS() {
		return BUILD_STATUS;
	}

	public void setBUILD_STATUS(String bUILD_STATUS) {
		BUILD_STATUS = bUILD_STATUS;
	}

	public Date getBATCH_EXEC_DATE() {
		return BATCH_EXEC_DATE;
	}

	public void setBATCH_EXEC_DATE(Date bATCH_EXEC_DATE) {
		BATCH_EXEC_DATE = bATCH_EXEC_DATE;
	}

	public String getBUILD_FAILED_REASN() {
		return BUILD_FAILED_REASN;
	}

	public void setBUILD_FAILED_REASN(String bUILD_FAILED_REASN) {
		BUILD_FAILED_REASN = bUILD_FAILED_REASN;
	}

	public Date getBUILD_DATE() {
		return BUILD_DATE;
	}

	public void setBUILD_DATE(Date bUILD_DATE) {
		BUILD_DATE = bUILD_DATE;
	}

	public Timestamp getSTART_TS() {
		return START_TS;
	}

	public void setSTART_TS(Timestamp sTART_TS) {
		START_TS = sTART_TS;
	}

	public Timestamp getEND_TS() {
		return END_TS;
	}

	public void setEND_TS(Timestamp eND_TS) {
		END_TS = eND_TS;
	}

	
	public String getWORD_DOC_PATH() {
		return WORD_DOC_PATH;
	}

	public void setWORD_DOC_PATH(String wORD_DOC_PATH) {
		WORD_DOC_PATH = wORD_DOC_PATH;
	}


	public String getTEST_CASE_DESC() {
		return TEST_CASE_DESC;
	}

	public void setTEST_CASE_DESC(String tEST_CASE_DESC) {
		TEST_CASE_DESC = tEST_CASE_DESC;
	}


	public String getTEST_STEP_SCREENSHOT_NAME() {
		return TEST_STEP_SCREENSHOT_NAME;
	}

	public void setTEST_STEP_SCREENSHOT_NAME(String tEST_STEP_SCREENSHOT_NAME) {
		TEST_STEP_SCREENSHOT_NAME = tEST_STEP_SCREENSHOT_NAME;
	}


	private String FNCTNL_ITEM_INDCTR;
	
	private String BUILD_STATUS;
	
	private Date BATCH_EXEC_DATE;
	
	private String BUILD_FAILED_REASN;

	private Date BUILD_DATE;
	
	private Timestamp START_TS;
	
	private Timestamp END_TS;
	
	private String WORD_DOC_PATH;
	
	private String TEST_CASE_DESC;
	
	private String TEST_STEP_SCREENSHOT_NAME;

	
	
}

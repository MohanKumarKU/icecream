package com.fis.automation.controller;

import java.util.List;

import com.fis.automation.bean.BUILD_COVERAGE_BEAN;
import com.fis.automation.entity.BUILD_COVERAGE_ENTITY;
import com.fis.automation.helper.Entity2BeanHelper;
import com.fis.automation.persistance.GetCoverageDetailsPersistanceManager;

public class GetCoverageDetailsController 
{

private static GetCoverageDetailsPersistanceManager  manager=null; 
	
	
	private GetCoverageDetailsPersistanceManager getManager()
	{
		
		if(manager!=null) return manager;	
		return new GetCoverageDetailsPersistanceManager();
		
	}
	
	
	
	public List<String> getAllNonAutomatedServices(String build_no,String cmpreldtl_id)
	{
		return getManager().getAllNonAutomatedServices(build_no,cmpreldtl_id);
	}



	public int[] getAutomatedPercentage(String build_no, String cmpreldtl_id)
	{
		return getManager().getAutomatedPercentage(build_no,cmpreldtl_id);
	}



	public List<BUILD_COVERAGE_BEAN> getAutomatedTestcaseInfo(String build_no,
			String cmpreldtl_id)
	{
		List<BUILD_COVERAGE_ENTITY> entityList=getManager().getAutomatedTestcaseInfo(build_no,cmpreldtl_id);
		
		return Entity2BeanHelper.getCoverageBeanfromEntity(entityList);

	}

	
}

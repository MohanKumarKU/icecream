package com.fis.automation.persistance;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import com.fis.automation.sessionfact.GetHibernateSessionFactory;

public class GetTestCaseListPersistance
{

	SQLQuery sqlquery=null;
	
	public Map<String, String> getTestCaseList(String build_no,
			String cmpreldtl_id) 
	{
		
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		String query="select distinct TEST_CASE_NAME from BUILD_HIST_DTL where BUILD_NMBR=? and CMPNT_RELEASE_DTL_ID=? and BUILD_STATUS='N'";
		SQLQuery sqlquery=session.createSQLQuery(query);
		
		sqlquery.setParameter(0, build_no);
		sqlquery.setParameter(1, cmpreldtl_id);
		
		
		@SuppressWarnings("unchecked")
		List<String> testcaseList=(List<String>)sqlquery.list();
		
		

		query="select TEST_CASE_NAME from BUILD_HIST_DTL where BUILD_NMBR=? and CMPNT_RELEASE_DTL_ID=? group by TEST_CASE_NAME order by max(START_TS)";
		sqlquery=session.createSQLQuery(query);
		
		sqlquery.setParameter(0, build_no);
		sqlquery.setParameter(1, cmpreldtl_id);
		
		@SuppressWarnings("unchecked")
		List<String> alltestcaseList=(List<String>)sqlquery.list();
		
		
		Map<String,String> testcaseMap=new LinkedHashMap<String,String>();
		
		if(!alltestcaseList.isEmpty())
		{
		
			int i=0;
			
			for(String s:alltestcaseList)
			{
				
					if(testcaseList.contains(s))
						testcaseMap.put("failure"+(i++), s);
					else
						testcaseMap.put("success"+(i++), s);
			}
			
		}
		
		
		return testcaseMap;
		
	}

	public Map<String, String> getTestCaseStepCounts(String build_no,
			String cmpreldtl_id)
	{
		
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		String teststepscount="Select count(*) from BUILD_HIST_DTL where BUILD_NMBR=? and CMPNT_RELEASE_DTL_ID=?";
		SQLQuery sqlquery=session.createSQLQuery(teststepscount);
		
		sqlquery.setParameter(0, build_no);
		sqlquery.setParameter(1, cmpreldtl_id);
		
		BigDecimal teststepCounter=((List<BigDecimal>)sqlquery.list()).get(0);
		
		String totalteststeps="";
		if(teststepCounter!=null)
		totalteststeps=teststepCounter.toString();
		 
		
		  teststepscount="Select count(*) from BUILD_HIST_DTL where BUILD_NMBR=? and CMPNT_RELEASE_DTL_ID=? and BUILD_STATUS='Y'";
		  sqlquery=session.createSQLQuery(teststepscount);
			
		  	sqlquery.setParameter(0, build_no);
			sqlquery.setParameter(1, cmpreldtl_id);
			
			teststepCounter=((List<BigDecimal>)sqlquery.list()).get(0);
			
			String successteststeps="";
			if(teststepCounter!=null)
			successteststeps=teststepCounter.toString();
			
		 
	
		teststepscount="select count(*) from (select distinct TEST_CASE_NAME from BUILD_HIST_DTL where BUILD_NMBR=? and CMPNT_RELEASE_DTL_ID=?)";	
		 
		 sqlquery=session.createSQLQuery(teststepscount);
		
		 	sqlquery.setParameter(0, build_no);
			sqlquery.setParameter(1, cmpreldtl_id);
		
		teststepCounter=((List<BigDecimal>)sqlquery.list()).get(0);
		
		String totaltestcases="";
		
		if(teststepCounter!=null)
			 totaltestcases=teststepCounter.toString();
		 
		
		
		
	  	teststepscount= "select count(*) from (select distinct TEST_CASE_NAME from BUILD_HIST_DTL where BUILD_NMBR=? and CMPNT_RELEASE_DTL_ID=? and BUILD_STATUS='N')";
	  	
	  	 sqlquery=session.createSQLQuery(teststepscount);
	  	 sqlquery.setParameter(0, build_no);
	  	 sqlquery.setParameter(1, cmpreldtl_id);
		
	  	 List<BigDecimal> res=((List<BigDecimal>)sqlquery.list());
	  	 
	  	 if(res!=null && !res.isEmpty())
		teststepCounter=res.get(0);
	  	 else
	  		 teststepCounter=BigDecimal.ZERO;
	  		 
	  		 
	  	 
		String failuretestcases="";
		
		if(teststepCounter!=null)
			 failuretestcases=teststepCounter.toString();
		
		
		Map<String,String> result=new HashMap<String,String>(); 
		 
		result.put("totalteststeps", totalteststeps);
		result.put("successteststeps", successteststeps);
		result.put("failureteststeps", String.valueOf(Integer.parseInt(totalteststeps)-Integer.parseInt(successteststeps)) );
		
		
		result.put("totaltestcases", totaltestcases);
		result.put("failuretestcases", failuretestcases);
		result.put("successtestcases", String.valueOf(Integer.parseInt(totaltestcases)-Integer.parseInt(failuretestcases)));
		
		
		
		return result;
	}

}

package com.fis.automation.entity;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class MAX_TIME_SRVCNAME_EMBED implements Serializable
{
	/**
	 * 
	 */
	private static long serialVersionUID = 1L;
	
	private String SRVC_NAME;
	

	public String getSRVC_NAME() {
		return SRVC_NAME;
	}

	public void setSRVC_NAME(String sRVC_NAME) {
		SRVC_NAME = sRVC_NAME;
	}

	private String CMPNT_RELEASE_DTL_ID;

	public String getCMPNT_RELEASE_DTL_ID() {
		return CMPNT_RELEASE_DTL_ID;
	}

	public void setCMPNT_RELEASE_DTL_ID(String cMPNT_RELEASE_DTL_ID) {
		CMPNT_RELEASE_DTL_ID = cMPNT_RELEASE_DTL_ID;
	}
}

package com.fis.automation.bean;

public class BUILD_COVERAGE_BEAN 
{

	private String BUILD_NMBR;
	
	private String CMPNT_RELEASE_DTL_ID;
	
	private String SRVC_OPRTN_NAME;
	
	private String TEST_CASE_CNT;
	
	private String TEST_STEP_CNT;

	public String getBUILD_NMBR() {
		return BUILD_NMBR;
	}

	public void setBUILD_NMBR(String bUILD_NMBR) {
		BUILD_NMBR = bUILD_NMBR;
	}

	public String getCMPNT_RELEASE_DTL_ID() {
		return CMPNT_RELEASE_DTL_ID;
	}

	public void setCMPNT_RELEASE_DTL_ID(String cMPNT_RELEASE_DTL_ID) {
		CMPNT_RELEASE_DTL_ID = cMPNT_RELEASE_DTL_ID;
	}

	public String getSRVC_OPRTN_NAME() {
		return SRVC_OPRTN_NAME;
	}

	public void setSRVC_OPRTN_NAME(String sRVC_OPRTN_NAME) {
		SRVC_OPRTN_NAME = sRVC_OPRTN_NAME;
	}

	public String getTEST_CASE_CNT() {
		return TEST_CASE_CNT;
	}

	public void setTEST_CASE_CNT(String tEST_CASE_CNT) {
		TEST_CASE_CNT = tEST_CASE_CNT;
	}

	public String getTEST_STEP_CNT() {
		return TEST_STEP_CNT;
	}

	public void setTEST_STEP_CNT(String tEST_STEP_CNT) {
		TEST_STEP_CNT = tEST_STEP_CNT;
	}
	
	
	
}

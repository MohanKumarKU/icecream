package com.fis.automation.facade;

import java.util.List;

import com.fis.automation.bean.BUILD_HIST;
import com.fis.automation.bean.CMPNT_RELEASE_DTL;
import com.fis.automation.bean.CMPNT_RELEASE_DTL_ID;
import com.fis.automation.contract.GetCmpRelDbServerDetailsByIdContract;
import com.fis.automation.controller.GetCmpRelDbServerDetailsByIdController;

public class GetCmpRelDbServerDetailsByIdFacade implements
		GetCmpRelDbServerDetailsByIdContract {

	private static GetCmpRelDbServerDetailsByIdController controller = null;

	private GetCmpRelDbServerDetailsByIdController getController() {
		if (controller != null)
			return controller;

		return new GetCmpRelDbServerDetailsByIdController();

	}

	public List<CMPNT_RELEASE_DTL> getCmpRelDbServerDetails(String cmpreldtl_id) {
		return getController().getCmpRelDbServerDetails(cmpreldtl_id);
	}

	public List<BUILD_HIST> getLatestBuildHistDetails(String cmpreldtl_id) {

		return getController().getLatestBuildHistDetails(cmpreldtl_id);
	}

	public String getCmpntReleaseDtlId(String component, String release,
			String db, String server) {

		return getController().getCmpntReleaseDtlId(component, release, db,
				server);
	}

	public List<BUILD_HIST> getAllBuildsByComponentReleaseDtlId(
			String cmpreldtl_id) {

		return getController()
				.getAllBuildsByComponentReleaseDtlId(cmpreldtl_id);
	}

	public List<String> getAllowedServerDatabaseCombinations(String component,
			String release) {
		return getController().getAllowedServerDatabaseCombinations(component,
				release);
	}

	public List<CMPNT_RELEASE_DTL_ID> getCmpntReleaseIDDtl(String component,
			String release) {
		return getController().getCmpntReleaseIDDtl(component, release);
	}

}

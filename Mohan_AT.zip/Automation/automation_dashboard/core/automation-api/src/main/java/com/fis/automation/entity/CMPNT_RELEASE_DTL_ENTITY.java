package com.fis.automation.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity(name = "CMPNT_RELEASE_DTL")
public class CMPNT_RELEASE_DTL_ENTITY
{

   @Id
   private String CMPNT_RELEASE_DTL_ID;

   private String CMPNT_NAME;

   private String RELEASE_NMBR;

   private String DBMS_CL;

   private String APPS_CL;

   private String OS_CL;

   public String getCMPNT_RELEASE_DTL_ID()
   {
      return CMPNT_RELEASE_DTL_ID;
   }

   public void setCMPNT_RELEASE_DTL_ID(String cMPNT_RELEASE_DTL_ID)
   {
      CMPNT_RELEASE_DTL_ID = cMPNT_RELEASE_DTL_ID;
   }

   public String getCMPNT_NAME()
   {
      return CMPNT_NAME;
   }

   public void setCMPNT_NAME(String cMPNT_NAME)
   {
      CMPNT_NAME = cMPNT_NAME;
   }

   public String getRELEASE_NMBR()
   {
      return RELEASE_NMBR;
   }

   public void setRELEASE_NMBR(String rELEASE_NMBR)
   {
      RELEASE_NMBR = rELEASE_NMBR;
   }

   public String getDBMS_CL()
   {
      return DBMS_CL;
   }

   public void setDBMS_CL(String dBMS_CL)
   {
      DBMS_CL = dBMS_CL;
   }

   public String getAPPS_CL()
   {
      return APPS_CL;
   }

   public void setAPPS_CL(String aPPS_CL)
   {
      APPS_CL = aPPS_CL;
   }

   public String getOS_CL()
   {
      return OS_CL;
   }

   public void setOS_CL(String oS_CL)
   {
      OS_CL = oS_CL;
   }

}

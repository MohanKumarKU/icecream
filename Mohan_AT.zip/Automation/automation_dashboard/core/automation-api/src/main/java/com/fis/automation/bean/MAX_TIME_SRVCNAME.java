package com.fis.automation.bean;

public class MAX_TIME_SRVCNAME {

	private String CMPNT_RELEASE_DTL_ID;
	
	private String SRVC_NAME;
	
	private String COUNT_SRVCNAME;
	
	private String AVGTIME_MSEC;

	private String TOTALTIME_SEC;

	/*private String TEST_SUITE_NAME;

	private String TEST_CASE_NAME;

	private String TEST_STEP_NAME;
	
	private Date Build_Date;*/
	

	public String getCMPNT_RELEASE_DTL_ID() {
		return CMPNT_RELEASE_DTL_ID;
	}

	public void setCMPNT_RELEASE_DTL_ID(String cMPNT_RELEASE_DTL_ID) {
		CMPNT_RELEASE_DTL_ID = cMPNT_RELEASE_DTL_ID;
	}	

	public String getSRVC_NAME() {
		return SRVC_NAME;
	}

	public void setSRVC_NAME(String sRVC_NAME) {
		SRVC_NAME = sRVC_NAME;
	}

	/*public String getTEST_SUITE_NAME() {
		return TEST_SUITE_NAME;
	}

	public void setTEST_SUITE_NAME(String tEST_SUITE_NAME) {
		TEST_SUITE_NAME = tEST_SUITE_NAME;
	}

	public String getTEST_CASE_NAME() {
		return TEST_CASE_NAME;
	}

	public void setTEST_CASE_NAME(String tEST_CASE_NAME) {
		TEST_CASE_NAME = tEST_CASE_NAME;
	}

	public String getTEST_STEP_NAME() {
		return TEST_STEP_NAME;
	}

	public void setTEST_STEP_NAME(String tEST_STEP_NAME) {
		TEST_STEP_NAME = tEST_STEP_NAME;
	}	

	public Date getBuild_Date() {
		return Build_Date;
	}

	public void setBuild_Date(Date build_Date) {
		Build_Date = build_Date;
	}*/
	
	public String getCOUNT_SRVCNAME() {
		return COUNT_SRVCNAME;
	}

	public void setCOUNT_SRVCNAME(String cOUNT_SRVCNAME) {
		COUNT_SRVCNAME = cOUNT_SRVCNAME;
	}
	
	public String getAVGTIME_MSEC() {
		return AVGTIME_MSEC;
	}

	public void setAVGTIME_MSEC(String aVGTIME_MSEC) {
		AVGTIME_MSEC = aVGTIME_MSEC;
	}

	public String getTOTALTIME_SEC() {
		return TOTALTIME_SEC;
	}

	public void setTOTALTIME_SEC(String tOTALTIME_SEC) {
		TOTALTIME_SEC = tOTALTIME_SEC;
	}


}

package com.fis.automation.entity;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity(name = "BUILD_HIST_LATEST_RES")
@Table
public class BUILD_HIST_LATEST_RES_ENTITY {

	@EmbeddedId
	BUILD_HIST_LATEST_RES_EMBED embedId;

	private String BUILD_STATUS;

	//private String CMPNT_RELEASE_DTL_ID;

	private Date BUILD_DATE;

	private Timestamp BUID_START_TS;

	private Timestamp BUILD_END_TS;

	public BUILD_HIST_LATEST_RES_EMBED getEmbedId() {
		return embedId;
	}

	public void setEmbedId(BUILD_HIST_LATEST_RES_EMBED embedId) {
		this.embedId = embedId;
	}

	public String getBUILD_STATUS() {
		return BUILD_STATUS;
	}

	public void setBUILD_STATUS(String bUILD_STATUS) {
		BUILD_STATUS = bUILD_STATUS;
	}

	public Date getBUILD_DATE() {
		return BUILD_DATE;
	}

	public void setBUILD_DATE(Date bUILD_DATE) {
		BUILD_DATE = bUILD_DATE;
	}

	public Timestamp getBUID_START_TS() {
		return BUID_START_TS;
	}

	public void setBUID_START_TS(Timestamp bUID_START_TS) {
		BUID_START_TS = bUID_START_TS;
	}

	public Timestamp getBUILD_END_TS() {
		return BUILD_END_TS;
	}

	public void setBUILD_END_TS(Timestamp bUILD_END_TS) {
		BUILD_END_TS = bUILD_END_TS;
	}
	
	/*public String getCMPNT_RELEASE_DTL_ID() {
		return CMPNT_RELEASE_DTL_ID;
	}

	public void setCMPNT_RELEASE_DTL_ID(String cMPNT_RELEASE_DTL_ID) {
		CMPNT_RELEASE_DTL_ID = cMPNT_RELEASE_DTL_ID;
	}*/

}

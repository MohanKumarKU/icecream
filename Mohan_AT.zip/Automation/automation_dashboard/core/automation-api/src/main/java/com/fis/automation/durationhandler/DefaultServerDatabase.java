package com.fis.automation.durationhandler;

public class DefaultServerDatabase
{

	private static String DATABASE="ORACLE";
	
	private static String SERVER="WAS";

	public static String getDATABASE() {
		return DATABASE;
	}

	public static void setDATABASE(String dATABASE) {
		DefaultServerDatabase.DATABASE = dATABASE;
	}

	public static String getSERVER() {
		return SERVER;
	}

	public static void setSERVER(String sERVER) {
		DefaultServerDatabase.SERVER = sERVER;
	}
	
	
	
	
}

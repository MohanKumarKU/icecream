package com.fis.automation.test;

import java.util.List;

import com.fis.automation.bean.BUILD_HIST;
import com.fis.automation.bean.CMPNT_RELEASE_DTL;
import com.fis.automation.contract.GetCmpRelDbServerDetailsByIdContract;
import com.fis.automation.facade.GetCmpRelDbServerDetailsByIdFacade;

public class TestClass 
{

	public static void main(String[] args)
	{
		
		GetCmpRelDbServerDetailsByIdContract contract=
				new GetCmpRelDbServerDetailsByIdFacade();
		
	@SuppressWarnings("unused")
	List<CMPNT_RELEASE_DTL> bean=contract.getCmpRelDbServerDetails("DP0101PG");
		
	List<BUILD_HIST> build_data=contract.getLatestBuildHistDetails("DP0101PG");
	
	
	System.out.println("dhahd");
	
	}
	
	
}

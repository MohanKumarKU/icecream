package com.fis.automation.facade;

import java.util.List;

import com.fis.automation.bean.BUILD_COVERAGE_BEAN;
import com.fis.automation.contract.GetCoverageDetailsContract;
import com.fis.automation.controller.GetCoverageDetailsController;

public class GetCoverageDetailsFacade implements GetCoverageDetailsContract
{
	
private static GetCoverageDetailsController  controller=null; 
	
	
	private GetCoverageDetailsController getController()
	{
		
		if(controller!=null) return controller;
		
		return new GetCoverageDetailsController();
		
	}
	
	
	
	public List<String> getAllNonAutomatedServices(String build_no,String cmpreldtl_id) 
	{
		return getController().getAllNonAutomatedServices(build_no,cmpreldtl_id);
	}



	public int[] getAutomatedPercentage(String build_no, String cmpreldtl_id) 
	{
		return getController().getAutomatedPercentage(build_no,cmpreldtl_id);
	}



	public List<BUILD_COVERAGE_BEAN> getAutomatedTestcaseInfo(String build_no,
			String cmpreldtl_id) 
	{
		return getController().getAutomatedTestcaseInfo(build_no,cmpreldtl_id);
	}

}

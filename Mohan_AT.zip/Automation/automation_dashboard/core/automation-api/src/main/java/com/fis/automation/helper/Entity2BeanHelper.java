package com.fis.automation.helper;

import java.util.ArrayList;
import java.util.List;

import com.fis.automation.bean.BUILD_COVERAGE_BEAN;
import com.fis.automation.bean.BUILD_HIST;
import com.fis.automation.bean.BUILD_HIST_AVG_TIME;
import com.fis.automation.bean.BUILD_HIST_DTL;
import com.fis.automation.bean.BUILD_HIST_LATEST_RES;
import com.fis.automation.bean.CMPNT_RELEASE_DTL;
import com.fis.automation.bean.CMPNT_RELEASE_DTL_ID;
import com.fis.automation.bean.MAX_TIME_SRVCNAME;
import com.fis.automation.entity.BUILD_COVERAGE_ENTITY;
import com.fis.automation.entity.BUILD_HIST_AVG_TIME_ENTITY;
import com.fis.automation.entity.BUILD_HIST_DTL_ENTITY;
import com.fis.automation.entity.BUILD_HIST_ENTITY;
import com.fis.automation.entity.BUILD_HIST_LATEST_RES_ENTITY;
import com.fis.automation.entity.CMPNT_RELEASE_DTL_ENTITY;
import com.fis.automation.entity.CMPNT_RELEASE_DTL_ID_ENTITY;
import com.fis.automation.entity.MAX_TIME_SRVCNAME_ENTITY;
import com.fis.automation.persistance.GetCmpRelDbServerDetailsByIdPersistanceManager;

public class Entity2BeanHelper {

	public static List<CMPNT_RELEASE_DTL> getCmpRelDbServerDetailsEntity2Bean(
			List<CMPNT_RELEASE_DTL_ENTITY> entityList) {

		List<CMPNT_RELEASE_DTL> beanList = new ArrayList<CMPNT_RELEASE_DTL>();

		CMPNT_RELEASE_DTL bean = null;

		for (CMPNT_RELEASE_DTL_ENTITY entity : entityList) {
			bean = new CMPNT_RELEASE_DTL();

			bean.setAPP_CL(entity.getAPPS_CL());
			bean.setCMPNT_NAME(entity.getCMPNT_NAME());
			bean.setCMPNT_RELEASE_DTL_ID(entity.getCMPNT_RELEASE_DTL_ID());
			bean.setDBMS_CL(entity.getDBMS_CL());
			bean.setOS_CL(entity.getOS_CL());
			bean.setRELEASE_NMBR(entity.getRELEASE_NMBR());

			beanList.add(bean);
		}

		return beanList;

	}

	public static List<BUILD_HIST_LATEST_RES> getRequiredBuildInfoDetailsEntity2Bean(
			List<BUILD_HIST_LATEST_RES_ENTITY> entityList) {

		String diffMin = null;

		List<BUILD_HIST_LATEST_RES> beanList = new ArrayList<BUILD_HIST_LATEST_RES>();

		BUILD_HIST_LATEST_RES bean = null;

		GetCmpRelDbServerDetailsByIdPersistanceManager manager = new GetCmpRelDbServerDetailsByIdPersistanceManager();

		for (BUILD_HIST_LATEST_RES_ENTITY entity : entityList) {
			bean = new BUILD_HIST_LATEST_RES();

			List<CMPNT_RELEASE_DTL_ENTITY> cmpreleaseDtl = manager
					.getCmpRelDbServerDetails(entityList.get(0).getEmbedId()
							.getCMPNT_RELEASE_DTL_ID());

			bean.setCMPNT_NAME(cmpreleaseDtl.get(0).getCMPNT_NAME());
			bean.setDATABASE(cmpreleaseDtl.get(0).getDBMS_CL());
			bean.setRELEASE_NMBR(cmpreleaseDtl.get(0).getRELEASE_NMBR());
			bean.setCMPNT_RELEASE_DTL_ID(cmpreleaseDtl.get(0)
					.getCMPNT_RELEASE_DTL_ID());

			bean.setBUILD_DATE(entity.getBUILD_DATE());
			bean.setBUILD_NMBR(entity.getEmbedId().getBUILD_NMBR());
			bean.setBUILD_STATUS(entity.getBUILD_STATUS());

			bean.setBUID_START_TS(entity.getBUID_START_TS());
			bean.setBUILD_END_TS(entity.getBUILD_END_TS());

			bean.setTEST_CASE_COUNT(manager.getTestcaseCount(entity
					.getEmbedId().getBUILD_NMBR(), entity.getEmbedId()
					.getCMPNT_RELEASE_DTL_ID()));

			bean.setTEST_STEP_COUNT(manager.getTeststepCount(entity
					.getEmbedId().getBUILD_NMBR(), entity.getEmbedId()
					.getCMPNT_RELEASE_DTL_ID()));

			if (entity.getBUILD_END_TS() != null
					&& entity.getBUID_START_TS() != null) {

				long diff = entity.getBUILD_END_TS().getTime()
						- entity.getBUID_START_TS().getTime();

				// long diffSeconds = diff / 1000 % 60;
				long diffMinutes = diff / (60 * 1000) % 60;
				long diffHours = diff / (60 * 60 * 1000) % 24;

				if (diffMinutes < 10) {
					diffMin = "0" + diffMinutes;
					bean.setDuration(diffHours + "." + diffMin);
				} else {
					bean.setDuration(diffHours + "." + diffMinutes);
					// +":"+diffSeconds;
				}

			} else
				bean.setDuration(null);

			beanList.add(bean);
		}

		return beanList;

	}

	public static List<BUILD_HIST> getLatestBuildHistDetailsEntity2Bean(
			List<BUILD_HIST_ENTITY> entityList) {
		List<BUILD_HIST> beanList = new ArrayList<BUILD_HIST>();

		BUILD_HIST bean = null;

		GetCmpRelDbServerDetailsByIdPersistanceManager manager = new GetCmpRelDbServerDetailsByIdPersistanceManager();

		for (BUILD_HIST_ENTITY entity : entityList) {
			bean = new BUILD_HIST();

			List<CMPNT_RELEASE_DTL_ENTITY> cmpreleaseDtl = manager
					.getCmpRelDbServerDetails(entityList.get(0).getEmbedId()
							.getCMPNT_RELEASE_DTL_ID());

			bean.setTEST_CASE_COUNT(manager.getTestcaseCount(entity
					.getEmbedId().getBUILD_NMBR(), entity.getEmbedId()
					.getCMPNT_RELEASE_DTL_ID()));

			bean.setTEST_STEP_COUNT(manager.getTeststepCount(entity
					.getEmbedId().getBUILD_NMBR(), entity.getEmbedId()
					.getCMPNT_RELEASE_DTL_ID()));

			bean.setAPP_SERVER(cmpreleaseDtl.get(0).getAPPS_CL());
			bean.setCMPNT_NAME(cmpreleaseDtl.get(0).getCMPNT_NAME());
			bean.setDATABASE(cmpreleaseDtl.get(0).getDBMS_CL());
			bean.setRELEASE_NMBR(cmpreleaseDtl.get(0).getRELEASE_NMBR());

			bean.setBUILD_DATE(entity.getBUILD_DATE());
			bean.setBUILD_NMBR(entity.getEmbedId().getBUILD_NMBR());
			bean.setBUILD_STATUS(entity.getBUILD_STATUS());

			bean.setBUID_START_TS(entity.getBUID_START_TS());
			bean.setBUILD_END_TS(entity.getBUILD_END_TS());
			bean.setREPORT_PATH(entity.getREPORT_PATH());

			if (entity.getBUILD_END_TS() != null
					&& entity.getBUID_START_TS() != null) {
				long diff = entity.getBUILD_END_TS().getTime()
						- entity.getBUID_START_TS().getTime();

				long diffSeconds = diff / 1000 % 60;
				long diffMinutes = diff / (60 * 1000) % 60;
				long diffHours = diff / (60 * 60 * 1000) % 24;

				bean.setDuration(diffHours + ":" + diffMinutes + ":"
						+ diffSeconds);
			} else
				bean.setDuration(null);

			beanList.add(bean);
		}

		return beanList;
	}

	public static List<BUILD_HIST> getAllBuildsEntity2Bean(
			List<BUILD_HIST_ENTITY> entityList) {
		List<BUILD_HIST> beanList = new ArrayList<BUILD_HIST>();

		BUILD_HIST bean = null;

		GetCmpRelDbServerDetailsByIdPersistanceManager manager = new GetCmpRelDbServerDetailsByIdPersistanceManager();

		for (BUILD_HIST_ENTITY entity : entityList) {
			bean = new BUILD_HIST();

			List<CMPNT_RELEASE_DTL_ENTITY> cmpreleaseDtl = manager
					.getCmpRelDbServerDetails(entityList.get(0).getEmbedId()
							.getCMPNT_RELEASE_DTL_ID());

			bean.setAPP_SERVER(cmpreleaseDtl.get(0).getAPPS_CL());
			bean.setCMPNT_NAME(cmpreleaseDtl.get(0).getCMPNT_NAME());
			bean.setDATABASE(cmpreleaseDtl.get(0).getDBMS_CL());
			bean.setRELEASE_NMBR(cmpreleaseDtl.get(0).getRELEASE_NMBR());

			bean.setBUILD_DATE(entity.getBUILD_DATE());
			bean.setBUILD_NMBR(entity.getEmbedId().getBUILD_NMBR());
			bean.setBUILD_STATUS(entity.getBUILD_STATUS());

			beanList.add(bean);
		}

		return beanList;
	}

	public static List<BUILD_HIST_DTL> BuildHistDetailEntity2Bean(
			List<BUILD_HIST_DTL_ENTITY> entityList, String svn_path) {

		List<BUILD_HIST_DTL> beanList = new ArrayList<BUILD_HIST_DTL>();

		BUILD_HIST_DTL bean = null;

		for (BUILD_HIST_DTL_ENTITY entity : entityList) {
			bean = new BUILD_HIST_DTL();

			bean.setBUILD_NMBR(entity.getEmbedId().getBUILD_NMBR());
			bean.setCMPNT_RELEASE_DTL_ID(entity.getEmbedId()
					.getCMPNT_RELEASE_DTL_ID());
			bean.setTEST_SUITE_NAME(entity.getEmbedId().getTEST_SUITE_NAME());
			bean.setTEST_CASE_NAME(entity.getEmbedId().getTEST_CASE_NAME());
			bean.setTEST_STEP_NAME(entity.getEmbedId().getTEST_STEP_NAME());
			bean.setFNCTNL_ITEM_INDCTR(entity.getFNCTNL_ITEM_INDCTR());
			bean.setBUILD_STATUS(entity.getBUILD_STATUS());
			bean.setBATCH_EXEC_DATE(entity.getBATCH_EXEC_DATE());
			bean.setBUILD_FAILED_REASN(entity.getBUILD_FAILED_REASN());
			bean.setBUILD_DATE(entity.getBUILD_DATE());
			bean.setSTART_TS(entity.getSTART_TS());
			bean.setEND_TS(entity.getEND_TS());
			bean.setWORD_DOC_PATH(entity.getWORD_DOC_PATH());
			bean.setTEST_CASE_DESC(entity.getTEST_CASE_DESC());
			bean.setTEST_STEP_SCREENSHOT_NAME(entity.getTEST_STEP_SCREENSHOT_NAME());
			bean.setSVN_PATH(svn_path);

			if (entity.getEND_TS() != null && entity.getSTART_TS() != null) {
				long diff = entity.getEND_TS().getTime()
						- entity.getSTART_TS().getTime();

				long diffSeconds = diff / 1000 % 60;
				long diffMinutes = diff / (60 * 1000) % 60;
				long diffHours = diff / (60 * 60 * 1000) % 24;

				bean.setDuration(diffHours + ":" + diffMinutes + ":"
						+ diffSeconds);
			} else
				bean.setDuration(null);

			beanList.add(bean);
		}

		return beanList;

	}

	public static List<BUILD_COVERAGE_BEAN> getCoverageBeanfromEntity(
			List<BUILD_COVERAGE_ENTITY> entityList) {

		List<BUILD_COVERAGE_BEAN> beanList = new ArrayList<BUILD_COVERAGE_BEAN>();

		BUILD_COVERAGE_BEAN bean;

		for (BUILD_COVERAGE_ENTITY entity : entityList) {
			bean = new BUILD_COVERAGE_BEAN();

			bean.setBUILD_NMBR(entity.getEmbedId().getBUILD_NMBR());
			bean.setCMPNT_RELEASE_DTL_ID(entity.getEmbedId()
					.getCMPNT_RELEASE_DTL_ID());
			bean.setSRVC_OPRTN_NAME(entity.getSRVC_OPRTN_NAME());
			bean.setTEST_CASE_CNT(entity.getTEST_CASE_CNT());
			bean.setTEST_STEP_CNT(entity.getTEST_STEP_CNT());

			beanList.add(bean);
		}

		return beanList;
	}

	public static List<CMPNT_RELEASE_DTL_ID> getCmpntReleaseIDDtlEntity2Bean(
			List<CMPNT_RELEASE_DTL_ID_ENTITY> entityList) {

		List<CMPNT_RELEASE_DTL_ID> beanList = new ArrayList<CMPNT_RELEASE_DTL_ID>();

		CMPNT_RELEASE_DTL_ID bean = null;

		for (CMPNT_RELEASE_DTL_ID_ENTITY entity : entityList) {
			bean = new CMPNT_RELEASE_DTL_ID();

			bean.setCMPNT_RELEASE_DTL_ID(entity.getCMPNT_RELEASE_DTL_ID());

			beanList.add(bean);
		}

		return beanList;

	}

	public static List<BUILD_HIST_AVG_TIME> getAvgBVTTimeEntity2Bean(
			List<BUILD_HIST_AVG_TIME_ENTITY> entityList) {

		List<BUILD_HIST_AVG_TIME> beanList = new ArrayList<BUILD_HIST_AVG_TIME>();

		BUILD_HIST_AVG_TIME bean = null;

		for (BUILD_HIST_AVG_TIME_ENTITY entity : entityList) {
			bean = new BUILD_HIST_AVG_TIME();

			bean.setCMPNT_RELEASE_DTL_ID(entity.getCMPNT_RELEASE_DTL_ID());
			bean.setAVGTIME(entity.getAVGTIME());

			beanList.add(bean);
		}

		return beanList;

	}

	public static List<MAX_TIME_SRVCNAME> getMaxTimeScrvNameEntity2Bean(
			List<MAX_TIME_SRVCNAME_ENTITY> entityList) {

		List<MAX_TIME_SRVCNAME> beanList = new ArrayList<MAX_TIME_SRVCNAME>();
		
		MAX_TIME_SRVCNAME bean = null;
		
		for (MAX_TIME_SRVCNAME_ENTITY entity : entityList) {
			bean = new MAX_TIME_SRVCNAME();
			
			bean.setCMPNT_RELEASE_DTL_ID(entity.getEmbedId().getCMPNT_RELEASE_DTL_ID());
			bean.setSRVC_NAME(entity.getEmbedId().getSRVC_NAME());			
			/*bean.setTEST_SUITE_NAME(entity.getTEST_SUITE_NAME());
			bean.setTEST_CASE_NAME(entity.getTEST_CASE_NAME());
			bean.setTEST_STEP_NAME(entity.getTEST_STEP_NAME());	
			bean.setBuild_Date(entity.getBuild_Date());*/
			bean.setCOUNT_SRVCNAME(entity.getCOUNT_SRVCNAME()); 
			bean.setAVGTIME_MSEC(entity.getAVGTIME_MSEC());
			bean.setTOTALTIME_SEC(entity.getTOTALTIME_SEC());
			
			beanList.add(bean);
		}
		return beanList;
	}
}

package com.fis.automation.contract;

import java.util.List;

import com.fis.automation.bean.BUILD_COVERAGE_BEAN;

public interface GetCoverageDetailsContract 
{

		/** 
		 * get List of Non Automated Services by Id....
		 */
	
	List<String> getAllNonAutomatedServices(String build_no,String cmpreldtl_id);
	
		/** 
		 * get Automated Percentage...
		 */
	
	int [] getAutomatedPercentage(String build_no,String cmpreldtl_id);
	
	
	List<BUILD_COVERAGE_BEAN> getAutomatedTestcaseInfo(String build_no,String cmpreldtl_id);
	
	
}

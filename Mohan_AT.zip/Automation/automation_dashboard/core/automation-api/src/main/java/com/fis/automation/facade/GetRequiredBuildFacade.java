package com.fis.automation.facade;

import java.util.List;

import com.fis.automation.bean.BUILD_HIST;
import com.fis.automation.bean.BUILD_HIST_AVG_TIME;
import com.fis.automation.bean.BUILD_HIST_DTL;
import com.fis.automation.bean.BUILD_HIST_LATEST_RES;
import com.fis.automation.bean.MAX_TIME_SRVCNAME;
import com.fis.automation.contract.GetRequiredBuildContract;
import com.fis.automation.controller.GetRequiredBuildController;

public class GetRequiredBuildFacade implements GetRequiredBuildContract
{
private static GetRequiredBuildController controller=null;
	
	private GetRequiredBuildController getController()
	{
		
		if(controller!=null) return controller;
		
		return new GetRequiredBuildController();
		
	}

	public List<BUILD_HIST> getRequiredBuildInformation(String build_no,
			String cmpreldtl_id) 
	{
		return getController().getRequiredBuildInformation(build_no,cmpreldtl_id);
	}
	
	public List<BUILD_HIST_LATEST_RES> getRequiredBuildInfoDetails(String cmpreldtl_id) 
	{
		return getController().getRequiredBuildInfoDetails(cmpreldtl_id);
	}
	
	public List<BUILD_HIST_AVG_TIME> getAvgBVTTime(String component) 
	{
		return getController().getAvgBVTTime(component);
	}

	public List<BUILD_HIST_DTL> getAccordionContent(String build_no,
			String testcasename, String cmpreldtl_id,String component)
	{
		return getController().getAccordionContent(build_no,testcasename,cmpreldtl_id,component);
	}
	
	public List<MAX_TIME_SRVCNAME> getMaxTimeScrvName(String cmpreldtl_id) 
	{
		return getController().getMaxTimeScrvName(cmpreldtl_id);
	}

}

package com.fis.automation.controller;

import java.util.Map;

import com.fis.automation.persistance.GetTestCaseListPersistance;

public class GetTestCaseListController {

	GetTestCaseListPersistance manager=null;
	
	private GetTestCaseListPersistance getManager()
	{
		
		if(manager!=null) return manager;
		
		return new GetTestCaseListPersistance();
		
	}
	
	
	public Map<String, String> getTestCaseList(String build_no,
			String cmpreldtl_id) 
	{
		return getManager().getTestCaseList(build_no,cmpreldtl_id);
	}


	public Map<String, String> getTestCaseStepCounts(String build_no,
			String cmpreldtl_id)
	{
		return getManager().getTestCaseStepCounts(build_no,cmpreldtl_id);
	}

}

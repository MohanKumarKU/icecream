package com.fis.automation.bean;

public class BUILD_HIST_AVG_TIME {

	private String CMPNT_RELEASE_DTL_ID;

	private String AVGTIME;

	public String getAVGTIME() {
		return AVGTIME;
	}

	public void setAVGTIME(String aVGTIME) {
		AVGTIME = aVGTIME;
	}

	public String getCMPNT_RELEASE_DTL_ID() {
		return CMPNT_RELEASE_DTL_ID;
	}

	public void setCMPNT_RELEASE_DTL_ID(String cMPNT_RELEASE_DTL_ID) {
		CMPNT_RELEASE_DTL_ID = cMPNT_RELEASE_DTL_ID;
	}

}

package com.fis.automation.contract;

import java.util.List;

import com.fis.automation.bean.BUILD_HIST;
import com.fis.automation.bean.CMPNT_RELEASE_DTL;
import com.fis.automation.bean.CMPNT_RELEASE_DTL_ID;

public interface GetCmpRelDbServerDetailsByIdContract
{

	/** 
	 * from Id get Component, version , database server details ..
	 */
	
		List<CMPNT_RELEASE_DTL> getCmpRelDbServerDetails(String cmpreldtl_id);
	
	
	/** 	
	 * get Entire Build History status by Id...
	 */
		
		List<BUILD_HIST> getLatestBuildHistDetails(String cmpreldtl_id);
		
		
	/** 	
	 * get CMPNT RELEASE DETAIL Id ...
	 */
		
	String getCmpntReleaseDtlId(String component,String release,String db,String server);	
		
	
	/** 
	 * get All the Builds by Component Release Detail Id
	 */
	
	List<BUILD_HIST> getAllBuildsByComponentReleaseDtlId(String cmpreldtl_id);	
		
	
	
	/** 
	 * get Allowed Server Database Combinations by Component and Release
	 */
	
	List<String> getAllowedServerDatabaseCombinations(String component,String release);
	
	/** 
	 * get Allowed Database Combinations by Component and Release
	 */
	
	List<CMPNT_RELEASE_DTL_ID> getCmpntReleaseIDDtl(String component,String release);

		
}

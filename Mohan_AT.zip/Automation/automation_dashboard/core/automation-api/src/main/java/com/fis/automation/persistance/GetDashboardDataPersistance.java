package com.fis.automation.persistance;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.hibernate.Session;

import com.fis.automation.durationhandler.DurationStorer;
import com.fis.automation.sessionfact.GetHibernateSessionFactory;

public class GetDashboardDataPersistance {

	SQLQuery sqlquery=null;
	
	public List<String> getAllComponents()
	{
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		sqlquery=session.createSQLQuery("select CMPNT_NAME from CMPNT_DTL order by CMPNT_NAME");
		
		return sqlquery.list();
	}

	public Map<String, String> getLatestReleaseForComponents() 
	{
	
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		sqlquery=session.createSQLQuery("select CMPNT_NAME,MAX(RELEASE_NMBR) from CMPNT_RELEASE_DTL group by CMPNT_NAME");
		
		Map<String,String> releaseMap=new HashMap<String,String>();
		
		@SuppressWarnings("unchecked")
		List<Object[]> queryList=sqlquery.list();
			
		for(Object[] s:queryList)
		{
			releaseMap.put(String.valueOf(s[0]),String.valueOf(s[1]));
		}
		
		return releaseMap;
		
	}
	
	public String getPreviousReleaseForComponents(String cmpnt_name,String release_nmbr) 
	{
	
		Session session=GetHibernateSessionFactory.getHibernateSession();
		
		sqlquery=session.createSQLQuery("select MAX(RELEASE_NMBR) from CMPNT_RELEASE_DTL where RELEASE_NMBR < ?");
		sqlquery.setParameter(0,release_nmbr);
		
		@SuppressWarnings("rawtypes")
		List data= sqlquery.list();
		
		if(data!=null && !data.isEmpty())
		return String.valueOf(data.get(0));
		
		return null;
	}

}
